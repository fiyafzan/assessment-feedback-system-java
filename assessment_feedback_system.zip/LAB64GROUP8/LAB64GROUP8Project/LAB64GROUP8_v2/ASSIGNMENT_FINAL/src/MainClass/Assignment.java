
package MainClass;
import AcademicLeaderGUI.AcademicLeaderDashboard;
import AdminStaffGUI.AdminStaffPage;
import Classes.AcademicLeader;
import Classes.AdminStaff;
import Classes.DataIO;
import Classes.Lecturer;
import Classes.Login;
import Classes.Student;
import LecturerGUI.Lecturerpage;
import StudentGUI.StudentPage;

public class Assignment {
    public static Login one;
    public static AdminStaffPage second;
    public static StudentPage third;
    public static Lecturerpage fourth;
    public static AcademicLeaderDashboard fifth;
    
    public static AdminStaff loginAdmin = null;
    public static AcademicLeader loginAL = null;
    public static Lecturer loginLecturer = null;
    public static Student loginStudent = null;
    
    public static void main(String[] args) {
        DataIO.read();
        one = new Login();
        second = new AdminStaffPage();
        
        
    }
}
