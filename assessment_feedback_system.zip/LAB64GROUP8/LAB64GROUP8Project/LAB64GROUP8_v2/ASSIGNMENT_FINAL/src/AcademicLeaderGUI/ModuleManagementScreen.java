package AcademicLeaderGUI;

import Classes.DataIO;
import Classes.Module;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;

public class ModuleManagementScreen extends javax.swing.JFrame {

    private DefaultTableModel tableModel;

    public ModuleManagementScreen() {
        initComponents();
        setLocationRelativeTo(null);
        setupTable();
        loadModules();
    }

    private void setupTable() {
        tableModel = (DefaultTableModel) tblModules.getModel();
        tblModules.setDefaultEditor(Object.class, null);
    }

    private void loadModules() {
        tableModel.setRowCount(0);
        for (Module m : DataIO.allModules) {
            tableModel.addRow(new Object[]{
                m.getModuleName(),
                m.getClassesAsString()
            });
        }
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlHeader = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        pnlMain = new javax.swing.JPanel();
        pnlButtons = new javax.swing.JPanel();
        btnAdd = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblModules = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Module Management");
        setPreferredSize(new java.awt.Dimension(708, 430));
        setResizable(false);

        pnlHeader.setBackground(new java.awt.Color(0, 153, 255));
        pnlHeader.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblTitle.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("Module Management");
        pnlHeader.add(lblTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 30, -1, -1));

        getContentPane().add(pnlHeader, java.awt.BorderLayout.PAGE_START);

        pnlMain.setBackground(new java.awt.Color(204, 204, 204));
        pnlMain.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        pnlMain.setLayout(new java.awt.BorderLayout());

        pnlButtons.setBackground(new java.awt.Color(204, 204, 204));

        btnAdd.setBackground(new java.awt.Color(0, 153, 0));
        btnAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnAdd.setForeground(new java.awt.Color(255, 255, 255));
        btnAdd.setText("Add New Module");
        btnAdd.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });
        pnlButtons.add(btnAdd);

        btnEdit.setBackground(new java.awt.Color(0, 0, 204));
        btnEdit.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnEdit.setForeground(new java.awt.Color(255, 255, 255));
        btnEdit.setText("Edit Module");
        btnEdit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });
        pnlButtons.add(btnEdit);

        btnDelete.setBackground(new java.awt.Color(255, 0, 0));
        btnDelete.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnDelete.setForeground(new java.awt.Color(255, 255, 255));
        btnDelete.setText("Delete Module");
        btnDelete.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        pnlButtons.add(btnDelete);

        btnBack.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnBack.setText("Back");
        btnBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        pnlButtons.add(btnBack);

        pnlMain.add(pnlButtons, java.awt.BorderLayout.PAGE_START);

        tblModules.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Module Name", "Module Classes"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblModules);

        pnlMain.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        getContentPane().add(pnlMain, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
         String moduleName = JOptionPane.showInputDialog(this, 
            "Enter Module Name:");
        if (moduleName == null || moduleName.trim().isEmpty()) return;

        String classesInput = JOptionPane.showInputDialog(this,
            "Enter Classes (comma separated, e.g. L1,T1,T2)\nLeave blank if none:");

        Module newModule = new Module(moduleName.trim());
        if (classesInput != null && !classesInput.trim().isEmpty()) {
            String[] classes = classesInput.split(",");
            for (String c : classes) {
                newModule.addClass(c.trim());
            }
        }

        DataIO.allModules.add(newModule);
        DataIO.write();
        loadModules();

        JOptionPane.showMessageDialog(this, 
            "Module added successfully!", "Success", 
            JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
           int selectedRow = tblModules.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, 
                "Please select a module to edit!", "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        Module selected = DataIO.allModules.get(selectedRow);

        String newName = JOptionPane.showInputDialog(this,
            "Edit Module Name:", selected.getModuleName());
        if (newName == null || newName.trim().isEmpty()) return;

        String newClasses = JOptionPane.showInputDialog(this,
            "Edit Classes (comma separated):", selected.getClassesAsString());

        selected.setModuleName(newName.trim());
        // Clear and re-add classes
        selected.getClassNames().clear();
        if (newClasses != null && !newClasses.trim().isEmpty() 
            && !newClasses.trim().equals("None")) {
            for (String c : newClasses.split(",")) {
                selected.addClass(c.trim());
            }
        }

        DataIO.write();
        loadModules();

        JOptionPane.showMessageDialog(this, 
            "Module updated successfully!", "Success", 
            JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        int selectedRow = tblModules.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, 
                "Please select a module to delete!", "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete this module?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            DataIO.allModules.remove(selectedRow);
            DataIO.write();
            loadModules();
            JOptionPane.showMessageDialog(this, 
                "Module deleted successfully!", "Success", 
                JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    public static void main(String args[]) {
        try {
        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
            if ("Nimbus".equals(info.getName())) {
                javax.swing.UIManager.setLookAndFeel(info.getClassName());
                break;
            }
        }
    } catch (Exception ex) {
        java.util.logging.Logger.getLogger(ModuleManagementScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    }

    java.awt.EventQueue.invokeLater(new Runnable() {
        public void run() {
            
            new ModuleManagementScreen().setVisible(true);
        }
    });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JPanel pnlButtons;
    private javax.swing.JPanel pnlHeader;
    private javax.swing.JPanel pnlMain;
    private javax.swing.JTable tblModules;
    // End of variables declaration//GEN-END:variables
}
