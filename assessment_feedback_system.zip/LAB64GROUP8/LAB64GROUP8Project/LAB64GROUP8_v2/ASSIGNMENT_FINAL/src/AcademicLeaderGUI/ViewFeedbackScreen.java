package AcademicLeaderGUI;

import Classes.DataIO;
import Classes.FeedbackclassAss;
import Classes.Module;
import Classes.AssessmentTypeAss;
import javax.swing.table.DefaultTableModel;

public class ViewFeedbackScreen extends javax.swing.JFrame {

    private DefaultTableModel tableModel;

    public ViewFeedbackScreen() {
        initComponents();
        setLocationRelativeTo(null);
        setupTable();
        populateModuleFilter();
        populateAssessmentFilter();
        loadAllFeedbacks();
        
        // Add listener to update assessment filter when module changes
        cmbModuleFilter.addActionListener(e -> updateAssessmentFilter());
    }

    private void setupTable() {
        tableModel = (DefaultTableModel) tblFeedback.getModel();
        tblFeedback.setDefaultEditor(Object.class, null);
        tblFeedback.getColumnModel().getColumn(0).setPreferredWidth(120);
        tblFeedback.getColumnModel().getColumn(1).setPreferredWidth(120);
        tblFeedback.getColumnModel().getColumn(2).setPreferredWidth(120);
        tblFeedback.getColumnModel().getColumn(3).setPreferredWidth(300);
    }

    private void populateModuleFilter() {
        cmbModuleFilter.removeAllItems();
        cmbModuleFilter.addItem("All Modules");
        for (Module m : DataIO.allModules) {
            cmbModuleFilter.addItem(m.getModuleName());
        }
    }
    
    private void populateAssessmentFilter() {
        cmbAssessmentFilter.removeAllItems();
        cmbAssessmentFilter.addItem("All Assessments");
        
        // Get unique assessment types from AssessmentTypeAss
        for (AssessmentTypeAss a : DataIO.allAssessmentType) {
            // Check if this assessment type is already in the combo box
            boolean exists = false;
            for (int i = 0; i < cmbAssessmentFilter.getItemCount(); i++) {
                if (cmbAssessmentFilter.getItemAt(i).equals(a.getAssessmentType())) {
                    exists = true;
                    break;
                }
            }
            if (!exists) {
                cmbAssessmentFilter.addItem(a.getAssessmentType());
            }
        }
        
        // If no AssessmentTypeAss data, fall back to getting unique types from feedbacks
        if (cmbAssessmentFilter.getItemCount() == 1) {
            for (FeedbackclassAss f : DataIO.allFeedback) {
                boolean exists = false;
                for (int i = 0; i < cmbAssessmentFilter.getItemCount(); i++) {
                    if (cmbAssessmentFilter.getItemAt(i).equals(f.getAssessmentType())) {
                        exists = true;
                        break;
                    }
                }
                if (!exists) {
                    cmbAssessmentFilter.addItem(f.getAssessmentType());
                }
            }
        }
    }
    
    private void updateAssessmentFilter() {
        String selectedModule = (String) cmbModuleFilter.getSelectedItem();
        cmbAssessmentFilter.removeAllItems();
        cmbAssessmentFilter.addItem("All Assessments");
        
        if (selectedModule == null) return;
        
        if (selectedModule.equals("All Modules")) {
            // Show all assessment types
            populateAssessmentFilter();
        } else {
            // Show only assessment types for selected module
            for (AssessmentTypeAss a : DataIO.allAssessmentType) {
                if (a.getModule().equals(selectedModule)) {
                    cmbAssessmentFilter.addItem(a.getAssessmentType());
                }
            }
            
            // Fall back to feedbacks if no AssessmentTypeAss data
            if (cmbAssessmentFilter.getItemCount() == 1) {
                for (FeedbackclassAss f : DataIO.allFeedback) {
                    if (f.getModule().equals(selectedModule)) {
                        boolean exists = false;
                        for (int i = 0; i < cmbAssessmentFilter.getItemCount(); i++) {
                            if (cmbAssessmentFilter.getItemAt(i).equals(f.getAssessmentType())) {
                                exists = true;
                                break;
                            }
                        }
                        if (!exists) {
                            cmbAssessmentFilter.addItem(f.getAssessmentType());
                        }
                    }
                }
            }
        }
    }

    private void loadAllFeedbacks() {
        tableModel.setRowCount(0);
        
        int count = 0;
        for (FeedbackclassAss f : DataIO.allFeedback) {
            tableModel.addRow(new Object[]{
                f.getModule(),
                f.getStudentName(),
                f.getAssessmentType(),
                f.getFeedback()
            });
            count++;
        }
        
        updateStats(count);
    }

    private void filterFeedbacks() {
        String selectedModule = (String) cmbModuleFilter.getSelectedItem();
        String selectedAssessment = (String) cmbAssessmentFilter.getSelectedItem();
        
        tableModel.setRowCount(0);
        int count = 0;

        for (FeedbackclassAss f : DataIO.allFeedback) {
            boolean matchModule = selectedModule.equals("All Modules") || 
                                 f.getModule().equals(selectedModule);
            
            boolean matchAssessment = selectedAssessment.equals("All Assessments") || 
                                     f.getAssessmentType().equals(selectedAssessment);
            
            if (matchModule && matchAssessment) {
                tableModel.addRow(new Object[]{
                    f.getModule(),
                    f.getStudentName(),
                    f.getAssessmentType(),
                    f.getFeedback()
                });
                count++;
            }
        }
        
        updateStats(count);
        
        // Show message if no results
        if (count == 0) {
            txtFeedbackDetail.setText("No feedbacks found for the selected filters.");
        }
    }

    private void updateStats(int count) {
        lblTotalFeedbacks.setText("Total Feedbacks: " + count);
        
        // You can calculate average marks if you have that data
        // For now, just show count
        lblAvgMarks.setText("    |    Filtered Results: " + count);
        lblHighestMarks.setText("");
        
        txtFeedbackDetail.setText(""); // Clear detail on reload
    }

    private void showFeedbackDetail() {
        int row = tblFeedback.getSelectedRow();
        if (row != -1) {
            String module = (String) tableModel.getValueAt(row, 0);
            String student = (String) tableModel.getValueAt(row, 1);
            String type = (String) tableModel.getValueAt(row, 2);
            String feedback = (String) tableModel.getValueAt(row, 3);

            txtFeedbackDetail.setText(
                "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
                "  FEEDBACK DETAILS\n" +
                "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
                "  Module          : " + module + "\n" +
                "  Student         : " + student + "\n" +
                "  Assessment Type : " + type + "\n" +
                "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
                "  Feedback        : " + feedback + "\n" +
                "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            );
        }
    }

    // Keep your existing initComponents() - generated by Design View
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlBottom = new javax.swing.JPanel();
        btnBack = new javax.swing.JButton();
        pnlHeader = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        pnlCenter = new javax.swing.JPanel();
        pnlFilter = new javax.swing.JPanel();
        lblFilter = new javax.swing.JLabel();
        cmbModuleFilter = new javax.swing.JComboBox<>();
        lblAssessment = new javax.swing.JLabel();
        cmbAssessmentFilter = new javax.swing.JComboBox<>();
        btnFilter = new javax.swing.JButton();
        btnShowAll = new javax.swing.JButton();
        pnlContent = new javax.swing.JPanel();
        pnlSummary = new javax.swing.JPanel();
        lblTotalFeedbacks = new javax.swing.JLabel();
        lblAvgMarks = new javax.swing.JLabel();
        lblHighestMarks = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblFeedback = new javax.swing.JTable();
        pnlDetail = new javax.swing.JPanel();
        lblDetail = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtFeedbackDetail = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("View Lecturers Feedback");
        setPreferredSize(new java.awt.Dimension(1080, 444));
        setResizable(false);

        btnBack.setBackground(new java.awt.Color(204, 204, 204));
        btnBack.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnBack.setForeground(new java.awt.Color(0, 0, 0));
        btnBack.setText("Back");
        btnBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnBack.setPreferredSize(null);
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        pnlBottom.add(btnBack);

        getContentPane().add(pnlBottom, java.awt.BorderLayout.PAGE_END);

        pnlHeader.setBackground(new java.awt.Color(60, 153, 255));
        pnlHeader.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblTitle.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("View Lecturer Feedbacks");
        pnlHeader.add(lblTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 30, 300, -1));

        getContentPane().add(pnlHeader, java.awt.BorderLayout.PAGE_START);

        pnlCenter.setBackground(new java.awt.Color(204, 204, 204));
        pnlCenter.setLayout(new java.awt.BorderLayout());

        pnlFilter.setBackground(new java.awt.Color(0, 0, 0));

        lblFilter.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblFilter.setForeground(new java.awt.Color(255, 255, 255));
        lblFilter.setText("Filter by Module:");
        pnlFilter.add(lblFilter);

        cmbModuleFilter.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnlFilter.add(cmbModuleFilter);

        lblAssessment.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblAssessment.setForeground(new java.awt.Color(255, 255, 255));
        lblAssessment.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAssessment.setText("Filter by Assessment:");
        pnlFilter.add(lblAssessment);

        cmbAssessmentFilter.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnlFilter.add(cmbAssessmentFilter);

        btnFilter.setBackground(new java.awt.Color(0, 204, 0));
        btnFilter.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnFilter.setForeground(new java.awt.Color(255, 255, 255));
        btnFilter.setText("Filter");
        btnFilter.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFilterActionPerformed(evt);
            }
        });
        pnlFilter.add(btnFilter);

        btnShowAll.setBackground(new java.awt.Color(204, 204, 204));
        btnShowAll.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnShowAll.setForeground(new java.awt.Color(0, 0, 0));
        btnShowAll.setText("Show All");
        btnShowAll.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnShowAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShowAllActionPerformed(evt);
            }
        });
        pnlFilter.add(btnShowAll);

        pnlCenter.add(pnlFilter, java.awt.BorderLayout.PAGE_START);

        pnlContent.setBackground(new java.awt.Color(255, 255, 255));
        pnlContent.setLayout(new java.awt.BorderLayout());

        pnlSummary.setBackground(new java.awt.Color(204, 204, 204));

        lblTotalFeedbacks.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblTotalFeedbacks.setText("Total Feedbacks: 0");
        pnlSummary.add(lblTotalFeedbacks);

        lblAvgMarks.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblAvgMarks.setText("    |    Average Marks: 0");
        pnlSummary.add(lblAvgMarks);

        lblHighestMarks.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblHighestMarks.setText("    |    Highest Marks: 0");
        pnlSummary.add(lblHighestMarks);

        pnlContent.add(pnlSummary, java.awt.BorderLayout.PAGE_START);

        jScrollPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jScrollPane1MouseClicked(evt);
            }
        });

        tblFeedback.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Module", "Student", "Assessment Type", "Feedback"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblFeedback.setRowHeight(25);
        tblFeedback.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblFeedbackMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblFeedback);

        pnlContent.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        pnlDetail.setBackground(new java.awt.Color(255, 255, 255));
        pnlDetail.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblDetail.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblDetail.setForeground(new java.awt.Color(0, 0, 0));
        lblDetail.setText("Feedback Details:");
        pnlDetail.add(lblDetail, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 20, 150, -1));

        txtFeedbackDetail.setEditable(false);
        txtFeedbackDetail.setColumns(20);
        txtFeedbackDetail.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtFeedbackDetail.setLineWrap(true);
        txtFeedbackDetail.setRows(5);
        txtFeedbackDetail.setWrapStyleWord(true);
        jScrollPane2.setViewportView(txtFeedbackDetail);

        pnlDetail.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 0, -1, 60));

        pnlContent.add(pnlDetail, java.awt.BorderLayout.PAGE_END);

        pnlCenter.add(pnlContent, java.awt.BorderLayout.CENTER);

        getContentPane().add(pnlCenter, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jScrollPane1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jScrollPane1MouseClicked
        
    }//GEN-LAST:event_jScrollPane1MouseClicked

    private void btnFilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFilterActionPerformed
        filterFeedbacks();
    }//GEN-LAST:event_btnFilterActionPerformed

    private void btnShowAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowAllActionPerformed
        cmbModuleFilter.setSelectedIndex(0);
        cmbAssessmentFilter.setSelectedIndex(0);
        loadAllFeedbacks();
    }//GEN-LAST:event_btnShowAllActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    private void tblFeedbackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblFeedbackMouseClicked
        showFeedbackDetail();
    }//GEN-LAST:event_tblFeedbackMouseClicked
    
    
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info :
                 javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(
                ViewFeedbackScreen.class.getName()).log(
                java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewFeedbackScreen().setVisible(true);
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnFilter;
    private javax.swing.JButton btnShowAll;
    private javax.swing.JComboBox<String> cmbAssessmentFilter;
    private javax.swing.JComboBox<String> cmbModuleFilter;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblAssessment;
    private javax.swing.JLabel lblAvgMarks;
    private javax.swing.JLabel lblDetail;
    private javax.swing.JLabel lblFilter;
    private javax.swing.JLabel lblHighestMarks;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblTotalFeedbacks;
    private javax.swing.JPanel pnlBottom;
    private javax.swing.JPanel pnlCenter;
    private javax.swing.JPanel pnlContent;
    private javax.swing.JPanel pnlDetail;
    private javax.swing.JPanel pnlFilter;
    private javax.swing.JPanel pnlHeader;
    private javax.swing.JPanel pnlSummary;
    private javax.swing.JTable tblFeedback;
    private javax.swing.JTextArea txtFeedbackDetail;
    // End of variables declaration//GEN-END:variables
}
