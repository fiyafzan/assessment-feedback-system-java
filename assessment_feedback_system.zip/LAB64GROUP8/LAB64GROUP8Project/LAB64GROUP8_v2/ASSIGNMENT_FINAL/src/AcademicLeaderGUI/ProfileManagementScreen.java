package AcademicLeaderGUI;

import MainClass.Assignment;
import Classes.DataIO;
import javax.swing.JOptionPane;

public class ProfileManagementScreen extends javax.swing.JFrame {

    public ProfileManagementScreen() {
        initComponents();
        setLocationRelativeTo(null);
        loadProfile();
    }

    private void loadProfile() {
        txtUsername.setText(Assignment.loginAL.getUsername());
        txtName.setText(Assignment.loginAL.getFullname());
        txtEmail.setText(Assignment.loginAL.getEmail());
        txtPhone.setText(Assignment.loginAL.getPhone());
        txtAge.setText(Assignment.loginAL.getAge());
        txtPassword.setText(Assignment.loginAL.getPassword());
    }

    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlHeader = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        pnlMain = new javax.swing.JPanel();
        lblUserID = new javax.swing.JLabel();
        txtUsername = new javax.swing.JTextField();
        lblName = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        lblPassword = new javax.swing.JLabel();
        txtPassword = new javax.swing.JTextField();
        lblPhone = new javax.swing.JLabel();
        txtPhone = new javax.swing.JTextField();
        btnSave = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        lblAge = new javax.swing.JLabel();
        txtAge = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Profile Management");
        setPreferredSize(new java.awt.Dimension(548, 400));
        setResizable(false);

        pnlHeader.setBackground(new java.awt.Color(0, 153, 255));
        pnlHeader.setPreferredSize(new java.awt.Dimension(500, 80));
        pnlHeader.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblTitle.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("Edit Profile");
        pnlHeader.add(lblTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 30, -1, -1));

        getContentPane().add(pnlHeader, java.awt.BorderLayout.PAGE_START);

        pnlMain.setPreferredSize(new java.awt.Dimension(502, 350));
        pnlMain.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblUserID.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblUserID.setText("Username:");
        pnlMain.add(lblUserID, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, -1, -1));

        txtUsername.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnlMain.add(txtUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 20, 250, -1));

        lblName.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblName.setText("Full Name:");
        pnlMain.add(lblName, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 50, -1, -1));

        txtName.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnlMain.add(txtName, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, 250, -1));

        lblEmail.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblEmail.setText("Email:");
        pnlMain.add(lblEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 80, -1, -1));

        txtEmail.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnlMain.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 80, 250, -1));

        lblPassword.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblPassword.setText("Password:");
        pnlMain.add(lblPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 110, -1, -1));

        txtPassword.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnlMain.add(txtPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 110, 250, -1));

        lblPhone.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblPhone.setText("Phone Number:");
        pnlMain.add(lblPhone, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 140, -1, -1));

        txtPhone.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnlMain.add(txtPhone, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 140, 250, -1));

        btnSave.setBackground(new java.awt.Color(0, 204, 0));
        btnSave.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnSave.setForeground(new java.awt.Color(255, 255, 255));
        btnSave.setText("Save Changes");
        btnSave.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });
        pnlMain.add(btnSave, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 250, -1, -1));

        btnBack.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        pnlMain.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 250, -1, -1));

        lblAge.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblAge.setText("Age:");
        pnlMain.add(lblAge, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 170, -1, -1));

        txtAge.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        pnlMain.add(txtAge, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 170, 250, -1));

        getContentPane().add(pnlMain, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
        String username = txtUsername.getText().trim();
        String fullname = txtName.getText().trim();
        String email = txtEmail.getText().trim();
        String phone = txtPhone.getText().trim();
        String age = txtAge.getText().trim();
        String password = txtPassword.getText().trim();

        if (username.isEmpty() || fullname.isEmpty() || email.isEmpty() || 
            phone.isEmpty() || age.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "All fields must be filled!", "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Update the loginAL object directly
        Assignment.loginAL.setUsername(username);
        Assignment.loginAL.setFullname(fullname);
        Assignment.loginAL.setEmail(email);
        Assignment.loginAL.setPhone(phone);
        Assignment.loginAL.setAge(age);
        Assignment.loginAL.setPassword(password);

        // Save to file
        DataIO.write();

        JOptionPane.showMessageDialog(this, 
            "Profile updated successfully!", "Success", 
            JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnSaveActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed
    
    

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ProfileManagementScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ProfileManagementScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ProfileManagementScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ProfileManagementScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
                
                new ProfileManagementScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnSave;
    private javax.swing.JLabel lblAge;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblPassword;
    private javax.swing.JLabel lblPhone;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblUserID;
    private javax.swing.JPanel pnlHeader;
    private javax.swing.JPanel pnlMain;
    private javax.swing.JTextField txtAge;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtPassword;
    private javax.swing.JTextField txtPhone;
    private javax.swing.JTextField txtUsername;
    // End of variables declaration//GEN-END:variables
}
