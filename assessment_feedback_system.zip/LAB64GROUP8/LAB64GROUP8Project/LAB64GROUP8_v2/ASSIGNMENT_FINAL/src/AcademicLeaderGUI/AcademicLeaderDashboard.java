package AcademicLeaderGUI;

import MainClass.Assignment;
import javax.swing.JOptionPane;

public class AcademicLeaderDashboard extends javax.swing.JFrame {

    public AcademicLeaderDashboard() {
        initComponents();
        setLocationRelativeTo(null);
        displayWelcomeMessage();
    }

    private void displayWelcomeMessage() {
        lblWelcome.setText("Welcome, " + Assignment.loginAL.getFullname());
        // If you don't have lblDepartment, remove this line
        // lblDepartment.setText("Role: " + Assignment.loginAL.getRole());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlHeader = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        lblWelcome = new javax.swing.JLabel();
        pnlMain = new javax.swing.JPanel();
        btnProfile = new javax.swing.JButton();
        btnModules = new javax.swing.JButton();
        btnAssignLecturers = new javax.swing.JButton();
        btnReports = new javax.swing.JButton();
        btnLogout = new javax.swing.JButton();
        btnViewFeedback = new javax.swing.JButton();
        btnViewStudentFeedback = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Academic Leader Dashboard");
        setPreferredSize(new java.awt.Dimension(557, 450));
        setResizable(false);

        pnlHeader.setBackground(new java.awt.Color(0, 153, 255));
        pnlHeader.setPreferredSize(new java.awt.Dimension(700, 120));
        pnlHeader.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblTitle.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("Academic Leader Dashboard");
        pnlHeader.add(lblTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 40, -1, -1));

        lblWelcome.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        lblWelcome.setForeground(new java.awt.Color(255, 255, 255));
        lblWelcome.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblWelcome.setText("Welcome, [Name}");
        pnlHeader.add(lblWelcome, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 90, -1, -1));

        getContentPane().add(pnlHeader, java.awt.BorderLayout.PAGE_START);

        pnlMain.setBackground(new java.awt.Color(204, 204, 204));
        pnlMain.setPreferredSize(new java.awt.Dimension(555, 500));
        pnlMain.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnProfile.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnProfile.setText("Edit Profile");
        btnProfile.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnProfile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProfileActionPerformed(evt);
            }
        });
        pnlMain.add(btnProfile, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 20, 200, -1));

        btnModules.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnModules.setText("Manage Modules");
        btnModules.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnModules.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModulesActionPerformed(evt);
            }
        });
        pnlMain.add(btnModules, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 50, 200, -1));

        btnAssignLecturers.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnAssignLecturers.setText("Assign Lecturers");
        btnAssignLecturers.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAssignLecturers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAssignLecturersActionPerformed(evt);
            }
        });
        pnlMain.add(btnAssignLecturers, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 80, 200, -1));

        btnReports.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnReports.setText("View Analyzed Reports");
        btnReports.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnReports.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReportsActionPerformed(evt);
            }
        });
        pnlMain.add(btnReports, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 110, 200, -1));

        btnLogout.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLogout.setText("LOGOUT");
        btnLogout.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });
        pnlMain.add(btnLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 220, -1, -1));

        btnViewFeedback.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnViewFeedback.setText("View Lecturers Feedback");
        btnViewFeedback.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnViewFeedback.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewFeedbackActionPerformed(evt);
            }
        });
        pnlMain.add(btnViewFeedback, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 140, 200, -1));

        btnViewStudentFeedback.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnViewStudentFeedback.setText("View Student Feedback");
        btnViewStudentFeedback.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnViewStudentFeedback.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewStudentFeedbackActionPerformed(evt);
            }
        });
        pnlMain.add(btnViewStudentFeedback, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 170, 200, -1));

        getContentPane().add(pnlMain, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
         int confirm = JOptionPane.showConfirmDialog(this,
        "Are you sure you want to logout?",
        "Confirm Logout",
        JOptionPane.YES_NO_OPTION);
    
    if (confirm == JOptionPane.YES_OPTION) {
        Assignment.one.x.setVisible(true);
        this.dispose();
    }
    }//GEN-LAST:event_btnLogoutActionPerformed

    private void btnProfileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProfileActionPerformed
        new ProfileManagementScreen().setVisible(true);
    }//GEN-LAST:event_btnProfileActionPerformed

    private void btnModulesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModulesActionPerformed
        new ModuleManagementScreen().setVisible(true);
    }//GEN-LAST:event_btnModulesActionPerformed

    private void btnAssignLecturersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAssignLecturersActionPerformed
        new AssignLecturersScreen().setVisible(true);
    }//GEN-LAST:event_btnAssignLecturersActionPerformed

    private void btnReportsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReportsActionPerformed
        new ReportsScreen().setVisible(true);
    }//GEN-LAST:event_btnReportsActionPerformed

    private void btnViewFeedbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewFeedbackActionPerformed
        new ViewFeedbackScreen().setVisible(true);

    }//GEN-LAST:event_btnViewFeedbackActionPerformed

    private void btnViewStudentFeedbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewStudentFeedbackActionPerformed
        new ViewStudentFeedbackScreen().setVisible(true);
    }//GEN-LAST:event_btnViewStudentFeedbackActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AcademicLeaderDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AcademicLeaderDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AcademicLeaderDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AcademicLeaderDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
    java.awt.EventQueue.invokeLater(new Runnable() {
    public void run() {
        
        new AcademicLeaderDashboard().setVisible(true);  
    }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAssignLecturers;
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnModules;
    private javax.swing.JButton btnProfile;
    private javax.swing.JButton btnReports;
    private javax.swing.JButton btnViewFeedback;
    private javax.swing.JButton btnViewStudentFeedback;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblWelcome;
    private javax.swing.JPanel pnlHeader;
    private javax.swing.JPanel pnlMain;
    // End of variables declaration//GEN-END:variables
}
