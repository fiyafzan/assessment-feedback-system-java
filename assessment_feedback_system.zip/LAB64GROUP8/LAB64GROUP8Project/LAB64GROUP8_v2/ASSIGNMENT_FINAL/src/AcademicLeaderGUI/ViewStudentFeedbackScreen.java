package AcademicLeaderGUI;

import Classes.DataIO;
import Classes.StudentFeedback;
import Classes.Lecturer;
import Classes.Module;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ViewStudentFeedbackScreen extends javax.swing.JFrame {

    private DefaultTableModel tableModel;

    public ViewStudentFeedbackScreen() {
        initComponents();
        setLocationRelativeTo(null);
        setupTable();
        populateFilters();
        loadAllFeedbacks();
        
        // Add listener to update lecturer filter when module changes
        cmbModuleFilter.addActionListener(e -> updateLecturerFilter());
    }

    private void setupTable() {
        tableModel = (DefaultTableModel) tblFeedback.getModel();
        tblFeedback.setDefaultEditor(Object.class, null);
        
        // Set column widths
        tblFeedback.getColumnModel().getColumn(0).setPreferredWidth(120); // Student
        tblFeedback.getColumnModel().getColumn(1).setPreferredWidth(150); // Lecturer
        tblFeedback.getColumnModel().getColumn(2).setPreferredWidth(150); // Module
        tblFeedback.getColumnModel().getColumn(3).setPreferredWidth(80);  // Rating
        tblFeedback.getColumnModel().getColumn(4).setPreferredWidth(100); // Date
    }

    private void populateFilters() {
        // Populate Module Filter
        cmbModuleFilter.removeAllItems();
        cmbModuleFilter.addItem("All Modules");
        for (Module m : DataIO.allModules) {
            cmbModuleFilter.addItem(m.getModuleName());
        }
        
        // Populate Lecturer Filter (all lecturers initially)
        updateLecturerFilter();
    }
    
    private void updateLecturerFilter() {
        String selectedModule = (String) cmbModuleFilter.getSelectedItem();
        cmbLecturerFilter.removeAllItems();
        cmbLecturerFilter.addItem("All Lecturers");
        
        if (selectedModule == null) return;
        
        if (selectedModule.equals("All Modules")) {
            // Show all lecturers
            for (Lecturer l : DataIO.allLecturer) {
                cmbLecturerFilter.addItem(l.getFullname());
            }
        } else {
            // Show only lecturers teaching this module
            for (Lecturer l : DataIO.allLecturer) {
                if (l.getModule().equals(selectedModule)) {
                    cmbLecturerFilter.addItem(l.getFullname());
                }
            }
            
            // If no lecturers found for module, show all
            if (cmbLecturerFilter.getItemCount() == 1) {
                for (Lecturer l : DataIO.allLecturer) {
                    cmbLecturerFilter.addItem(l.getFullname());
                }
            }
        }
    }

    private void loadAllFeedbacks() {
        tableModel.setRowCount(0);
        
        int count = 0;
        int totalRating = 0;
        int fiveStarCount = 0;
        
        for (StudentFeedback sf : DataIO.allStudentFeedback) {
            tableModel.addRow(new Object[]{
                sf.getStudentName(),
                sf.getLecturerName(),
                sf.getModule(),
                getStarRating(sf.getRating()),
                sf.getTimestamp()
            });
            
            count++;
            totalRating += sf.getRating();
            if (sf.getRating() == 5) fiveStarCount++;
        }
        
        updateStats(count, totalRating, fiveStarCount);
        
        if (count == 0) {
            JOptionPane.showMessageDialog(this,
                "No student feedback found in the system!",
                "No Data", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void filterFeedbacks() {
        String selectedModule = (String) cmbModuleFilter.getSelectedItem();
        String selectedLecturer = (String) cmbLecturerFilter.getSelectedItem();
        String selectedRating = (String) cmbRatingFilter.getSelectedItem();
        
        tableModel.setRowCount(0);
        
        int count = 0;
        int totalRating = 0;
        int fiveStarCount = 0;
        
        // Parse minimum rating
        int minRating = 0;
        if (!selectedRating.equals("All")) {
            minRating = Integer.parseInt(selectedRating.substring(0, 1));
        }

        for (StudentFeedback sf : DataIO.allStudentFeedback) {
            boolean matchModule = selectedModule.equals("All Modules") || 
                                 sf.getModule().equals(selectedModule);
            
            boolean matchLecturer = selectedLecturer.equals("All Lecturers") || 
                                   sf.getLecturerName().equals(selectedLecturer);
            
            boolean matchRating = selectedRating.equals("All") || 
                                 sf.getRating() >= minRating;
            
            if (matchModule && matchLecturer && matchRating) {
                tableModel.addRow(new Object[]{
                    sf.getStudentName(),
                    sf.getLecturerName(),
                    sf.getModule(),
                    getStarRating(sf.getRating()),
                    sf.getTimestamp()
                });
                
                count++;
                totalRating += sf.getRating();
                if (sf.getRating() == 5) fiveStarCount++;
            }
        }
        
        updateStats(count, totalRating, fiveStarCount);
        
        if (count == 0) {
            txtComments.setText("No feedbacks found for the selected filters.");
        }
    }

    private void showFeedbackDetail() {
        int row = tblFeedback.getSelectedRow();
        if (row != -1) {
            String studentName = (String) tableModel.getValueAt(row, 0);
            String lecturerName = (String) tableModel.getValueAt(row, 1);
            String module = (String) tableModel.getValueAt(row, 2);
            String rating = (String) tableModel.getValueAt(row, 3);
            String date = (String) tableModel.getValueAt(row, 4);
            
            // Find the full feedback in DataIO
            for (StudentFeedback sf : DataIO.allStudentFeedback) {
                if (sf.getStudentName().equals(studentName) && 
                    sf.getLecturerName().equals(lecturerName) &&
                    sf.getTimestamp().equals(date)) {
                    
                    txtComments.setText(
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
                        "  STUDENT FEEDBACK DETAILS\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
                        "  Student      : " + studentName + "\n" +
                        "  Lecturer     : " + lecturerName + "\n" +
                        "  Module       : " + module + "\n" +
                        "  Rating       : " + rating + " (" + sf.getRating() + "/5)\n" +
                        "  Date         : " + date + "\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
                        "  Comments:\n" +
                        "  " + sf.getComments() + "\n" +
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                    );
                    break;
                }
            }
        }
    }

    private void updateStats(int count, int totalRating, int fiveStarCount) {
        double avgRating = count > 0 ? (double) totalRating / count : 0.0;
        
        lblTotalFeedbacks.setText("Total Feedbacks: " + count);
        lblAvgRating.setText("   |   Average Rating: " + String.format("%.1f", avgRating) + "/5");
        lblFiveStars.setText("   |   5-Star Reviews: " + fiveStarCount);
    }

    private String getStarRating(int rating) {
        StringBuilder stars = new StringBuilder();
        for (int i = 0; i < rating; i++) {
            stars.append("★");
        }
        for (int i = rating; i < 5; i++) {
            stars.append("☆");
        }
        return stars.toString();
    }

    // Your initComponents() - keep as generated by Design View
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlHeader = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        pnlBottom = new javax.swing.JPanel();
        btnBack = new javax.swing.JButton();
        pnlCenter = new javax.swing.JPanel();
        pnlFilter = new javax.swing.JPanel();
        lblFilterModule = new javax.swing.JLabel();
        cmbModuleFilter = new javax.swing.JComboBox<>();
        lblLecturerFilter = new javax.swing.JLabel();
        cmbLecturerFilter = new javax.swing.JComboBox<>();
        lblRatingFilter = new javax.swing.JLabel();
        cmbRatingFilter = new javax.swing.JComboBox<>();
        btnFilter = new javax.swing.JButton();
        btnShowAll = new javax.swing.JButton();
        pnlContent = new javax.swing.JPanel();
        pnlSummary = new javax.swing.JPanel();
        lblTotalFeedbacks = new javax.swing.JLabel();
        lblAvgRating = new javax.swing.JLabel();
        lblFiveStars = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblFeedback = new javax.swing.JTable();
        pnlDetail = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtComments = new javax.swing.JTextArea();
        lblFeedbackDetails = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("View Student Feedback");
        setPreferredSize(new java.awt.Dimension(907, 340));
        setResizable(false);

        pnlHeader.setBackground(new java.awt.Color(60, 153, 255));
        pnlHeader.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblTitle.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("View Student Feedbacks");
        pnlHeader.add(lblTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 20, -1, -1));

        getContentPane().add(pnlHeader, java.awt.BorderLayout.PAGE_START);

        pnlBottom.setBackground(new java.awt.Color(204, 204, 204));

        btnBack.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBack.setText("Back");
        btnBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        pnlBottom.add(btnBack);

        getContentPane().add(pnlBottom, java.awt.BorderLayout.PAGE_END);

        pnlCenter.setLayout(new java.awt.BorderLayout());

        pnlFilter.setBackground(new java.awt.Color(204, 204, 204));

        lblFilterModule.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblFilterModule.setForeground(new java.awt.Color(0, 0, 0));
        lblFilterModule.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFilterModule.setText("Filter by Module:");
        pnlFilter.add(lblFilterModule);

        pnlFilter.add(cmbModuleFilter);

        lblLecturerFilter.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblLecturerFilter.setForeground(new java.awt.Color(0, 0, 0));
        lblLecturerFilter.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLecturerFilter.setText("Filter by Lecturer:");
        pnlFilter.add(lblLecturerFilter);

        pnlFilter.add(cmbLecturerFilter);

        lblRatingFilter.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblRatingFilter.setForeground(new java.awt.Color(0, 0, 0));
        lblRatingFilter.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblRatingFilter.setText("Rating:");
        pnlFilter.add(lblRatingFilter);

        cmbRatingFilter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "5 Stars", "4 Stars", "3 Stars", "2 Stars", "1 Stars", " " }));
        pnlFilter.add(cmbRatingFilter);

        btnFilter.setBackground(new java.awt.Color(0, 153, 0));
        btnFilter.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnFilter.setForeground(new java.awt.Color(255, 255, 255));
        btnFilter.setText("Filter");
        btnFilter.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFilterActionPerformed(evt);
            }
        });
        pnlFilter.add(btnFilter);

        btnShowAll.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnShowAll.setText("Show All");
        btnShowAll.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnShowAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShowAllActionPerformed(evt);
            }
        });
        pnlFilter.add(btnShowAll);

        pnlCenter.add(pnlFilter, java.awt.BorderLayout.PAGE_START);

        pnlContent.setLayout(new java.awt.BorderLayout());

        pnlSummary.setBackground(new java.awt.Color(204, 204, 204));

        lblTotalFeedbacks.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblTotalFeedbacks.setText("Total Feedbacks: 0");
        pnlSummary.add(lblTotalFeedbacks);

        lblAvgRating.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblAvgRating.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAvgRating.setText("   |   Average Rating: 0.0");
        pnlSummary.add(lblAvgRating);

        lblFiveStars.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblFiveStars.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFiveStars.setText("   |   5 Star Ratings: 0");
        pnlSummary.add(lblFiveStars);

        pnlContent.add(pnlSummary, java.awt.BorderLayout.PAGE_START);

        tblFeedback.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Student Name", "Lecturer Name", "Module", "Rating", "Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblFeedback.setRowHeight(25);
        tblFeedback.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblFeedbackMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblFeedback);

        pnlContent.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        pnlDetail.setBackground(new java.awt.Color(255, 255, 255));
        pnlDetail.setLayout(new java.awt.BorderLayout());

        txtComments.setEditable(false);
        txtComments.setColumns(20);
        txtComments.setLineWrap(true);
        txtComments.setRows(5);
        txtComments.setWrapStyleWord(true);
        jScrollPane2.setViewportView(txtComments);

        pnlDetail.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        lblFeedbackDetails.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblFeedbackDetails.setForeground(new java.awt.Color(0, 0, 0));
        lblFeedbackDetails.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFeedbackDetails.setText("Feedback Details:");
        pnlDetail.add(lblFeedbackDetails, java.awt.BorderLayout.PAGE_START);

        pnlContent.add(pnlDetail, java.awt.BorderLayout.PAGE_END);

        pnlCenter.add(pnlContent, java.awt.BorderLayout.CENTER);

        getContentPane().add(pnlCenter, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnFilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFilterActionPerformed
        filterFeedbacks();
    }//GEN-LAST:event_btnFilterActionPerformed

    private void btnShowAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowAllActionPerformed
        cmbModuleFilter.setSelectedIndex(0);
        cmbLecturerFilter.setSelectedIndex(0);
        cmbRatingFilter.setSelectedIndex(0);
        loadAllFeedbacks();
        txtComments.setText("");
    }//GEN-LAST:event_btnShowAllActionPerformed

    private void tblFeedbackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblFeedbackMouseClicked
        showFeedbackDetail();
    }//GEN-LAST:event_tblFeedbackMouseClicked

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ViewStudentFeedbackScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ViewStudentFeedbackScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ViewStudentFeedbackScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ViewStudentFeedbackScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewStudentFeedbackScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnFilter;
    private javax.swing.JButton btnShowAll;
    private javax.swing.JComboBox<String> cmbLecturerFilter;
    private javax.swing.JComboBox<String> cmbModuleFilter;
    private javax.swing.JComboBox<String> cmbRatingFilter;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblAvgRating;
    private javax.swing.JLabel lblFeedbackDetails;
    private javax.swing.JLabel lblFilterModule;
    private javax.swing.JLabel lblFiveStars;
    private javax.swing.JLabel lblLecturerFilter;
    private javax.swing.JLabel lblRatingFilter;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblTotalFeedbacks;
    private javax.swing.JPanel pnlBottom;
    private javax.swing.JPanel pnlCenter;
    private javax.swing.JPanel pnlContent;
    private javax.swing.JPanel pnlDetail;
    private javax.swing.JPanel pnlFilter;
    private javax.swing.JPanel pnlHeader;
    private javax.swing.JPanel pnlSummary;
    private javax.swing.JTable tblFeedback;
    private javax.swing.JTextArea txtComments;
    // End of variables declaration//GEN-END:variables
}
