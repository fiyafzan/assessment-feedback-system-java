package StudentGUI;

import MainClass.Assignment;
import Classes.DataIO;
import Classes.Student;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Edit Profile page for students
 * Allows students to update their personal information
 * Demonstrates: Encapsulation, GUI programming, File I/O
 */
public class EditProfileStudent extends JFrame implements ActionListener {
    
    // GUI Components
    private JPanel headerPanel;
    private JPanel formPanel;
    private JPanel buttonPanel;
    
    private JLabel titleLabel;
    private JLabel usernameLabel, passwordLabel, fullnameLabel, emailLabel, phoneLabel, ageLabel, moduleLabel;
    
    private JTextField usernameField, fullnameField, emailField, phoneField, ageField, moduleField;
    private JPasswordField currentPasswordField, newPasswordField, confirmPasswordField;
    private JCheckBox showCurrentPasswordCheckBox, showNewPasswordCheckBox, showConfirmPasswordCheckBox;
    
    private JButton saveBtn;
    private JButton cancelBtn;
    
    private Student currentStudent;
    
    public EditProfileStudent() {
        currentStudent = Assignment.loginStudent;
        initComponents();
        loadStudentData();
    }
    
    /**
     * Initialize all GUI components
     */
    private void initComponents() {
        // Frame settings
        setTitle("Edit Profile - Student");
        setSize(550, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(247, 247, 247));
        
        // Header Panel
        headerPanel = new JPanel();
        headerPanel.setBackground(new Color(220, 20, 60));
        headerPanel.setBorder(BorderFactory.createMatteBorder(0, 3, 3, 0, new Color(180, 0, 40)));
        headerPanel.setPreferredSize(new Dimension(550, 80));
        headerPanel.setLayout(new GridBagLayout());
        
        titleLabel = new JLabel("Edit Your Profile");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(new Color(255, 255, 153));
        headerPanel.add(titleLabel);
        
        // Form Panel
        formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(30, 40, 20, 40));
        formPanel.setBackground(new Color(247, 247, 247));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Username (read-only)
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(usernameLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        usernameField = new JTextField(20);
        usernameField.setEditable(false);
        usernameField.setBackground(new Color(230, 230, 230));
        usernameField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(usernameField, gbc);
        
        // Full Name
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;
        fullnameLabel = new JLabel("Full Name:");
        fullnameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(fullnameLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        fullnameField = new JTextField(20);
        fullnameField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(fullnameField, gbc);
        
        // Email
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0;
        emailLabel = new JLabel("Email:");
        emailLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(emailLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        emailField = new JTextField(20);
        emailField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(emailField, gbc);
        
        // Phone
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0;
        phoneLabel = new JLabel("Phone:");
        phoneLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(phoneLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        phoneField = new JTextField(20);
        phoneField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(phoneField, gbc);
        
        // Age
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.weightx = 0;
        ageLabel = new JLabel("Age:");
        ageLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(ageLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        ageField = new JTextField(20);
        ageField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(ageField, gbc);
        
        // Module (read-only for now - would be changed through class registration)
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.weightx = 0;
        moduleLabel = new JLabel("Current Module:");
        moduleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(moduleLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        moduleField = new JTextField(20);
        moduleField.setEditable(false);
        moduleField.setBackground(new Color(230, 230, 230));
        moduleField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(moduleField, gbc);
        
        // === PASSWORD CHANGE SECTION ===
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.weightx = 0;
        JLabel passwordSectionLabel = new JLabel("Change Password (Optional)");
        passwordSectionLabel.setFont(new Font("Arial", Font.BOLD, 16));
        passwordSectionLabel.setForeground(new Color(220, 20, 60));
        passwordSectionLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        formPanel.add(passwordSectionLabel, gbc);
        
        // Current Password
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 1;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.WEST;
        passwordLabel = new JLabel("Current Password:");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(passwordLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        currentPasswordField = new JPasswordField(20);
        currentPasswordField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(currentPasswordField, gbc);
        
        // Show password checkbox for current password
        gbc.gridx = 1;
        gbc.gridy = 7;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        showCurrentPasswordCheckBox = new JCheckBox("Show");
        showCurrentPasswordCheckBox.setFont(new Font("Arial", Font.PLAIN, 11));
        showCurrentPasswordCheckBox.setFocusPainted(false);
        showCurrentPasswordCheckBox.addActionListener(this);
        formPanel.add(showCurrentPasswordCheckBox, gbc);
        gbc.anchor = GridBagConstraints.WEST;  // Reset anchor
        
        // New Password
        gbc.gridx = 0;
        gbc.gridy = 8;
        gbc.weightx = 0;
        JLabel newPasswordLabel = new JLabel("New Password:");
        newPasswordLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(newPasswordLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        newPasswordField = new JPasswordField(20);
        newPasswordField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(newPasswordField, gbc);
        
        // Show password checkbox for new password
        gbc.gridx = 1;
        gbc.gridy = 8;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        showNewPasswordCheckBox = new JCheckBox("Show");
        showNewPasswordCheckBox.setFont(new Font("Arial", Font.PLAIN, 11));
        showNewPasswordCheckBox.setFocusPainted(false);
        showNewPasswordCheckBox.addActionListener(this);
        formPanel.add(showNewPasswordCheckBox, gbc);
        gbc.anchor = GridBagConstraints.WEST;  // Reset anchor
        
        // Confirm Password
        gbc.gridx = 0;
        gbc.gridy = 9;
        gbc.weightx = 0;
        JLabel confirmPasswordLabel = new JLabel("Confirm New Password:");
        confirmPasswordLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(confirmPasswordLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        confirmPasswordField = new JPasswordField(20);
        confirmPasswordField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(confirmPasswordField, gbc);
        
        // Show password checkbox for confirm password
        gbc.gridx = 1;
        gbc.gridy = 9;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        showConfirmPasswordCheckBox = new JCheckBox("Show");
        showConfirmPasswordCheckBox.setFont(new Font("Arial", Font.PLAIN, 11));
        showConfirmPasswordCheckBox.setFocusPainted(false);
        showConfirmPasswordCheckBox.addActionListener(this);
        formPanel.add(showConfirmPasswordCheckBox, gbc);
        gbc.anchor = GridBagConstraints.WEST;  // Reset anchor
        
        // Password hint
        gbc.gridx = 0;
        gbc.gridy = 10;
        gbc.gridwidth = 2;
        JLabel passwordHint = new JLabel("Leave password fields empty if you don't want to change password");
        passwordHint.setFont(new Font("Arial", Font.ITALIC, 11));
        passwordHint.setForeground(Color.GRAY);
        formPanel.add(passwordHint, gbc);
        gbc.gridwidth = 1;  // Reset to 1
        
        // Button Panel
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(new Color(247, 247, 247));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 20, 40));
        
        saveBtn = new JButton("Save Changes");
        saveBtn.setFont(new Font("Arial", Font.BOLD, 14));
        saveBtn.setBackground(new Color(34, 139, 34));
        saveBtn.setForeground(Color.WHITE);
        saveBtn.setFocusPainted(false);
        saveBtn.setPreferredSize(new Dimension(150, 40));
        saveBtn.addActionListener(this);
        
        cancelBtn = new JButton("Cancel");
        cancelBtn.setFont(new Font("Arial", Font.BOLD, 14));
        cancelBtn.setBackground(new Color(200, 200, 200));
        cancelBtn.setForeground(Color.BLACK);
        cancelBtn.setFocusPainted(false);
        cancelBtn.setPreferredSize(new Dimension(150, 40));
        cancelBtn.addActionListener(this);
        
        buttonPanel.add(saveBtn);
        buttonPanel.add(cancelBtn);
        
        // Add panels to frame
        add(headerPanel, BorderLayout.NORTH);
        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    /**
     * Load current student data into form fields
     */
    private void loadStudentData() {
        if (currentStudent != null) {
            usernameField.setText(currentStudent.getUsername());
            fullnameField.setText(currentStudent.getFullname());
            emailField.setText(currentStudent.getEmail());
            phoneField.setText(currentStudent.getPhone());
            ageField.setText(currentStudent.getAge());
            moduleField.setText(currentStudent.getModule());
        }
    }
    
    /**
     * Validate input fields
     */
    private boolean validateInput() {
        if (fullnameField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Full name cannot be empty!", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (emailField.getText().trim().isEmpty() || !emailField.getText().contains("@")) {
            JOptionPane.showMessageDialog(this, "Please enter a valid email address!", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (phoneField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Phone number cannot be empty!", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try {
            int age = Integer.parseInt(ageField.getText().trim());
            if (age < 16 || age > 100) {
                JOptionPane.showMessageDialog(this, "Please enter a valid age (16-100)!", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Age must be a number!", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Password validation (only if user wants to change password)
        String currentPassword = new String(currentPasswordField.getPassword());
        String newPassword = new String(newPasswordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        
        // Check if user is trying to change password
        if (!currentPassword.isEmpty() || !newPassword.isEmpty() || !confirmPassword.isEmpty()) {
            // Verify current password
            if (!currentPassword.equals(currentStudent.getPassword())) {
                JOptionPane.showMessageDialog(this, 
                    "Current password is incorrect!", 
                    "Password Error", 
                    JOptionPane.ERROR_MESSAGE);
                return false;
            }
            
            // Check new password is not empty
            if (newPassword.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "New password cannot be empty!", 
                    "Password Error", 
                    JOptionPane.ERROR_MESSAGE);
                return false;
            }
            
            // Check password length
            if (newPassword.length() < 6) {
                JOptionPane.showMessageDialog(this, 
                    "New password must be at least 6 characters!", 
                    "Password Error", 
                    JOptionPane.ERROR_MESSAGE);
                return false;
            }
            
            // Check passwords match
            if (!newPassword.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(this, 
                    "New passwords do not match!", 
                    "Password Error", 
                    JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Handle button click events
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        // Handle show/hide password checkboxes
        if (e.getSource() == showCurrentPasswordCheckBox) {
            togglePasswordVisibility(currentPasswordField, showCurrentPasswordCheckBox);
            return;
        } else if (e.getSource() == showNewPasswordCheckBox) {
            togglePasswordVisibility(newPasswordField, showNewPasswordCheckBox);
            return;
        } else if (e.getSource() == showConfirmPasswordCheckBox) {
            togglePasswordVisibility(confirmPasswordField, showConfirmPasswordCheckBox);
            return;
        }
        
        // Handle Save and Cancel buttons
        if (e.getSource() == saveBtn) {
            if (validateInput()) {
                // Update student object
                currentStudent.setFullname(fullnameField.getText().trim());
                currentStudent.setEmail(emailField.getText().trim());
                currentStudent.setPhone(phoneField.getText().trim());
                currentStudent.setAge(ageField.getText().trim());
                
                // Update password if user changed it
                String newPassword = new String(newPasswordField.getPassword());
                if (!newPassword.isEmpty()) {
                    currentStudent.setPassword(newPassword);
                }
                
                // Save to file
                DataIO.write();
                
                String message = "Profile updated successfully!";
                if (!newPassword.isEmpty()) {
                    message += "\nPassword has been changed.";
                }
                
                JOptionPane.showMessageDialog(this, 
                    message, 
                    "Success", 
                    JOptionPane.INFORMATION_MESSAGE);
                
                // Return to student page
                this.setVisible(false);
                Assignment.third = new StudentPage();
                Assignment.third.setVisible(true);
            }
            
        } else if (e.getSource() == cancelBtn) {
            // Return to student page without saving
            int choice = JOptionPane.showConfirmDialog(
                this,
                "Discard changes?",
                "Confirm Cancel",
                JOptionPane.YES_NO_OPTION
            );
            
            if (choice == JOptionPane.YES_OPTION) {
                this.setVisible(false);
                Assignment.third = new StudentPage();
                Assignment.third.setVisible(true);
            }
        }
    }
    
    /**
     * Toggle password visibility for a password field
     * Shows or hides password based on checkbox state
     * @param passwordField The JPasswordField to toggle
     * @param checkBox The checkbox controlling visibility
     */
    private void togglePasswordVisibility(JPasswordField passwordField, JCheckBox checkBox) {
        if (checkBox.isSelected()) {
            // Show password as plain text
            passwordField.setEchoChar((char) 0);  // 0 means no echo character
        } else {
            // Hide password with bullet character
            passwordField.setEchoChar('•');  // Bullet character for security
        }
    }
}
