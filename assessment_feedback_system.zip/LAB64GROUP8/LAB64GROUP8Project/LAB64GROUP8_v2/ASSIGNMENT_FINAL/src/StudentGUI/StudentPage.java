package StudentGUI;

import MainClass.Assignment;
import Classes.Student;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Main dashboard for Student users
 * Implements the student functionalities as per assignment requirements
 */
public class StudentPage extends JFrame implements ActionListener {
    
    // GUI Components
    private JPanel headerPanel;
    private JPanel buttonPanel;
    private JLabel titleLabel;
    private JLabel welcomeLabel;
    private JButton editProfileBtn;
    private JButton registerClassBtn;
    private JButton checkResultsBtn;
    private JButton provideFeedbackBtn;
    private JButton logoutBtn;
    
    public StudentPage() {
        initComponents();
        setupHeader();
    }
    
    /**
     * Setup the header with personalized welcome message
     */
    private void setupHeader() {
        Student student = Assignment.loginStudent;
        if (student != null && student.getFullname() != null) {
            welcomeLabel.setText("Welcome, " + student.getFullname());
        } else {
            welcomeLabel.setText("Welcome, Student");
        }
    }
    
    /**
     * Initialize all GUI components
     */
    private void initComponents() {
        // Frame settings
        setTitle("Student Dashboard - Assessment Feedback System");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(247, 247, 247));
        
        // Header Panel
        headerPanel = new JPanel();
        headerPanel.setBackground(new Color(220, 20, 60)); // Red color for student
        headerPanel.setBorder(BorderFactory.createMatteBorder(0, 3, 3, 0, new Color(180, 0, 40)));
        headerPanel.setPreferredSize(new Dimension(600, 100));
        headerPanel.setLayout(new GridBagLayout());
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        
        // Title Label
        titleLabel = new JLabel("Student Dashboard");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(new Color(255, 255, 153));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        headerPanel.add(titleLabel, gbc);
        
        // Welcome Label
        welcomeLabel = new JLabel("Welcome, Student");
        welcomeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        welcomeLabel.setForeground(Color.WHITE);
        gbc.gridy = 1;
        headerPanel.add(welcomeLabel, gbc);
        
        // Button Panel
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(5, 1, 20, 20));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(40, 60, 40, 60));
        buttonPanel.setBackground(new Color(247, 247, 247));
        
        // Create buttons with appropriate styling
        editProfileBtn = createStyledButton("Edit Profile", new Color(70, 130, 180));
        registerClassBtn = createStyledButton("Register for Classes", new Color(34, 139, 34));
        checkResultsBtn = createStyledButton("Check Results", new Color(255, 140, 0));
        provideFeedbackBtn = createStyledButton("Provide Feedback to Lecturer", new Color(148, 0, 211));
        logoutBtn = createStyledButton("Logout", new Color(200, 200, 200));
        logoutBtn.setForeground(Color.BLACK);
        
        // Add action listeners
        editProfileBtn.addActionListener(this);
        registerClassBtn.addActionListener(this);
        checkResultsBtn.addActionListener(this);
        provideFeedbackBtn.addActionListener(this);
        logoutBtn.addActionListener(this);
        
        // Add buttons to panel
        buttonPanel.add(editProfileBtn);
        buttonPanel.add(registerClassBtn);
        buttonPanel.add(checkResultsBtn);
        buttonPanel.add(provideFeedbackBtn);
        buttonPanel.add(logoutBtn);
        
        // Add panels to frame
        add(headerPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
    }
    
    /**
     * Helper method to create styled buttons
     */
    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Add hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(color.darker());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(color);
            }
        });
        
        return button;
    }
    
    /**
     * Handle button click events
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == editProfileBtn) {
            // Open Edit Profile page
            this.setVisible(false);
            EditProfileStudent editPage = new EditProfileStudent();
            editPage.setVisible(true);
            
        } else if (e.getSource() == registerClassBtn) {
            // Open Register Class page
            this.setVisible(false);
            RegisterClass registerPage = new RegisterClass();
            registerPage.setVisible(true);
            
        } else if (e.getSource() == checkResultsBtn) {
            // Open Check Results page
            this.setVisible(false);
            CheckResults resultsPage = new CheckResults();
            resultsPage.setVisible(true);
            
        } else if (e.getSource() == provideFeedbackBtn) {
            // Open Provide Feedback page
            this.setVisible(false);
            ProvideFeedback feedbackPage = new ProvideFeedback();
            feedbackPage.setVisible(true);
            
        } else if (e.getSource() == logoutBtn) {
            // Logout and return to login screen
            int choice = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to logout?",
                "Confirm Logout",
                JOptionPane.YES_NO_OPTION
            );
            
            if (choice == JOptionPane.YES_OPTION) {
         Assignment.one.x.setVisible(true);
        this.dispose();
            }
        }
    }
}
