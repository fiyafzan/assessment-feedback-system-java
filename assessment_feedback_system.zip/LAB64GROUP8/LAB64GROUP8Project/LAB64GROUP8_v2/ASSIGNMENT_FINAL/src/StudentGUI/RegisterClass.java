package StudentGUI;

import MainClass.Assignment;
import Classes.DataIO;
import Classes.Module;
import Classes.Student;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * Register Class page for students
 * Allows students to view available modules and register for classes
 * Demonstrates: ArrayList usage, GUI tables, Object relationships
 */
public class RegisterClass extends JFrame implements ActionListener {
    
    // GUI Components
    private JPanel headerPanel;
    private JPanel tablePanel;
    private JPanel buttonPanel;
    
    private JLabel titleLabel;
    private JLabel currentModuleLabel;
    
    private JTable moduleTable;
    private DefaultTableModel tableModel;
    private JScrollPane scrollPane;
    
    private JButton registerBtn;
    private JButton backBtn;
    
    private Student currentStudent;
    
    public RegisterClass() {
        currentStudent = Assignment.loginStudent;
        initComponents();
        loadModules();
    }
    
    /**
     * Initialize all GUI components
     */
    private void initComponents() {
        // Frame settings
        setTitle("Register for Classes - Student");
        setSize(700, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(247, 247, 247));
        
        // Header Panel
        headerPanel = new JPanel();
        headerPanel.setBackground(new Color(220, 20, 60));
        headerPanel.setBorder(BorderFactory.createMatteBorder(0, 3, 3, 0, new Color(180, 0, 40)));
        headerPanel.setPreferredSize(new Dimension(700, 100));
        headerPanel.setLayout(new GridBagLayout());
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        
        titleLabel = new JLabel("Available Modules");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(new Color(255, 255, 153));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        headerPanel.add(titleLabel, gbc);
        
        String currentModule = (currentStudent != null && currentStudent.getModule() != null) 
            ? currentStudent.getModule() : "None";
        currentModuleLabel = new JLabel("Current Module: " + currentModule);
        currentModuleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        currentModuleLabel.setForeground(Color.WHITE);
        gbc.gridy = 1;
        headerPanel.add(currentModuleLabel, gbc);
        
        // Table Panel
        tablePanel = new JPanel();
        tablePanel.setLayout(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 10, 40));
        tablePanel.setBackground(new Color(247, 247, 247));
        
        // Create table
        String[] columnNames = {"Code", "Module Name", "Classes"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table read-only
            }
        };
        
        moduleTable = new JTable(tableModel);
        moduleTable.setFont(new Font("Arial", Font.PLAIN, 13));
        moduleTable.setRowHeight(25);
        moduleTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        moduleTable.getTableHeader().setBackground(new Color(70, 130, 180));
        moduleTable.getTableHeader().setForeground(Color.WHITE);
        moduleTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        scrollPane = new JScrollPane(moduleTable);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Info Label
        JLabel infoLabel = new JLabel("Select a module from the table and click 'Register' to enroll");
        infoLabel.setFont(new Font("Arial", Font.ITALIC, 12));
        infoLabel.setForeground(Color.GRAY);
        infoLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        tablePanel.add(infoLabel, BorderLayout.SOUTH);
        
        // Button Panel
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(new Color(247, 247, 247));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 20, 40));
        
        registerBtn = new JButton("Register for Selected Module");
        registerBtn.setFont(new Font("Arial", Font.BOLD, 14));
        registerBtn.setBackground(new Color(34, 139, 34));
        registerBtn.setForeground(Color.WHITE);
        registerBtn.setFocusPainted(false);
        registerBtn.setPreferredSize(new Dimension(220, 40));
        registerBtn.addActionListener(this);
        
        backBtn = new JButton("Back to Dashboard");
        backBtn.setFont(new Font("Arial", Font.BOLD, 14));
        backBtn.setBackground(new Color(200, 200, 200));
        backBtn.setForeground(Color.BLACK);
        backBtn.setFocusPainted(false);
        backBtn.setPreferredSize(new Dimension(180, 40));
        backBtn.addActionListener(this);
        
        buttonPanel.add(registerBtn);
        buttonPanel.add(backBtn);
        
        // Add panels to frame
        add(headerPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    /**
     * Load all available modules from DataIO
     */
    private void loadModules() {
        // Clear existing rows
        tableModel.setRowCount(0);
        
        // Add modules from DataIO.allModules
        if (DataIO.allModules != null && !DataIO.allModules.isEmpty()) {
            for (Module module : DataIO.allModules) {
                // Get classes count
                int classCount = module.getClassNames().size();
                
                Object[] row = {
                    module.getModuleName().substring(0, Math.min(10, module.getModuleName().length())).toUpperCase(),
                    module.getModuleName(),
                    classCount + " classes"
                };
                tableModel.addRow(row);
            }
        } else {
            // Show message if no modules available
            JLabel noDataLabel = new JLabel("No modules available at this time");
            noDataLabel.setFont(new Font("Arial", Font.ITALIC, 14));
            noDataLabel.setForeground(Color.GRAY);
            noDataLabel.setHorizontalAlignment(SwingConstants.CENTER);
            tablePanel.removeAll();
            tablePanel.add(noDataLabel, BorderLayout.CENTER);
            tablePanel.revalidate();
            tablePanel.repaint();
        }
    }
    
    /**
     * Handle button click events
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == registerBtn) {
            int selectedRow = moduleTable.getSelectedRow();
            
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this,
                    "Please select a module to register!",
                    "No Selection",
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            // Get selected module details
            String moduleCode = (String) tableModel.getValueAt(selectedRow, 0);
            String moduleName = (String) tableModel.getValueAt(selectedRow, 1);
            
            // Confirm registration
            int choice = JOptionPane.showConfirmDialog(this,
                "Register for " + moduleName + " (" + moduleCode + ")?",
                "Confirm Registration",
                JOptionPane.YES_NO_OPTION);
            
            if (choice == JOptionPane.YES_OPTION) {
                // Update student's module
                currentStudent.setModule(moduleName);
                
                // Save to file
                DataIO.write();
                
                JOptionPane.showMessageDialog(this,
                    "Successfully registered for " + moduleName + "!",
                    "Registration Successful",
                    JOptionPane.INFORMATION_MESSAGE);
                
                // Update current module label
                currentModuleLabel.setText("Current Module: " + moduleName);
            }
            
        } else if (e.getSource() == backBtn) {
            // Return to student dashboard
            this.setVisible(false);
            Assignment.third = new StudentPage();
            Assignment.third.setVisible(true);
        }
    }
}
