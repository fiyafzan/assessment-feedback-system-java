package StudentGUI;

import MainClass.Assignment;
import Classes.DataIO;
import Classes.StudentFeedback;
import Classes.Lecturer;
import Classes.Student;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Provide Feedback page for students
 * Allows students to provide comments/feedback to lecturers
 * Demonstrates: Object relationships, File I/O, GUI components
 */
public class ProvideFeedback extends JFrame implements ActionListener {
    
    // GUI Components
    private JPanel headerPanel;
    private JPanel formPanel;
    private JPanel buttonPanel;
    
    private JLabel titleLabel;
    private JLabel instructionsLabel;
    private JLabel lecturerLabel;
    private JLabel moduleLabel;
    private JLabel ratingLabel;
    private JLabel commentsLabel;
    
    private JComboBox<String> lecturerComboBox;
    private JTextField moduleField;
    private JComboBox<Integer> ratingComboBox;
    private JTextArea commentsArea;
    private JScrollPane commentsScrollPane;
    
    private JButton submitBtn;
    private JButton clearBtn;
    private JButton backBtn;
    
    private Student currentStudent;
    
    public ProvideFeedback() {
        currentStudent = Assignment.loginStudent;
        initComponents();
    }
    
    /**
     * Initialize all GUI components
     */
    private void initComponents() {
        // Frame settings
        setTitle("Provide Feedback - Student");
        setSize(650, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(247, 247, 247));
        
        // Header Panel
        headerPanel = new JPanel();
        headerPanel.setBackground(new Color(220, 20, 60));
        headerPanel.setBorder(BorderFactory.createMatteBorder(0, 3, 3, 0, new Color(180, 0, 40)));
        headerPanel.setPreferredSize(new Dimension(650, 120));
        headerPanel.setLayout(new GridBagLayout());
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        
        titleLabel = new JLabel("Provide Feedback to Lecturer");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(new Color(255, 255, 153));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        headerPanel.add(titleLabel, gbc);
        
        instructionsLabel = new JLabel("Share your thoughts and feedback about the lecturer and module");
        instructionsLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        instructionsLabel.setForeground(Color.WHITE);
        gbc.gridy = 1;
        headerPanel.add(instructionsLabel, gbc);
        
        // Form Panel
        formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(30, 40, 20, 40));
        formPanel.setBackground(new Color(247, 247, 247));
        
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Lecturer Selection
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        lecturerLabel = new JLabel("Select Lecturer:");
        lecturerLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(lecturerLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        lecturerComboBox = new JComboBox<>();
        lecturerComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        loadLecturers();
        formPanel.add(lecturerComboBox, gbc);
        
        // Module
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;
        moduleLabel = new JLabel("Module:");
        moduleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(moduleLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        moduleField = new JTextField(20);
        moduleField.setFont(new Font("Arial", Font.PLAIN, 14));
        if (currentStudent != null && currentStudent.getModule() != null) {
            moduleField.setText(currentStudent.getModule());
        }
        formPanel.add(moduleField, gbc);
        
        // Rating
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0;
        ratingLabel = new JLabel("Rating (1-5 stars):");
        ratingLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(ratingLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        Integer[] ratings = {1, 2, 3, 4, 5};
        ratingComboBox = new JComboBox<>(ratings);
        ratingComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        ratingComboBox.setSelectedIndex(4); // Default to 5 stars
        formPanel.add(ratingComboBox, gbc);
        
        // Comments
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        commentsLabel = new JLabel("Your Comments:");
        commentsLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(commentsLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        commentsArea = new JTextArea(8, 20);
        commentsArea.setFont(new Font("Arial", Font.PLAIN, 13));
        commentsArea.setLineWrap(true);
        commentsArea.setWrapStyleWord(true);
        commentsArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.GRAY),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        commentsScrollPane = new JScrollPane(commentsArea);
        formPanel.add(commentsScrollPane, gbc);
        
        // Button Panel
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 10));
        buttonPanel.setBackground(new Color(247, 247, 247));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 20, 40));
        
        submitBtn = new JButton("Submit Feedback");
        submitBtn.setFont(new Font("Arial", Font.BOLD, 14));
        submitBtn.setBackground(new Color(34, 139, 34));
        submitBtn.setForeground(Color.WHITE);
        submitBtn.setFocusPainted(false);
        submitBtn.setPreferredSize(new Dimension(160, 40));
        submitBtn.addActionListener(this);
        
        clearBtn = new JButton("Clear Form");
        clearBtn.setFont(new Font("Arial", Font.BOLD, 14));
        clearBtn.setBackground(new Color(255, 140, 0));
        clearBtn.setForeground(Color.WHITE);
        clearBtn.setFocusPainted(false);
        clearBtn.setPreferredSize(new Dimension(130, 40));
        clearBtn.addActionListener(this);
        
        backBtn = new JButton("Back");
        backBtn.setFont(new Font("Arial", Font.BOLD, 14));
        backBtn.setBackground(new Color(200, 200, 200));
        backBtn.setForeground(Color.BLACK);
        backBtn.setFocusPainted(false);
        backBtn.setPreferredSize(new Dimension(100, 40));
        backBtn.addActionListener(this);
        
        buttonPanel.add(submitBtn);
        buttonPanel.add(clearBtn);
        buttonPanel.add(backBtn);
        
        // Add panels to frame
        add(headerPanel, BorderLayout.NORTH);
        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    /**
     * Load lecturers from DataIO
     */
    private void loadLecturers() {
        lecturerComboBox.removeAllItems();
        
        if (DataIO.allLecturer != null && !DataIO.allLecturer.isEmpty()) {
            for (Lecturer lecturer : DataIO.allLecturer) {
                lecturerComboBox.addItem(lecturer.getFullname());
            }
        } else {
            lecturerComboBox.addItem("No lecturers available");
        }
    }
    
    /**
     * Validate input fields
     */
    private boolean validateInput() {
        if (lecturerComboBox.getSelectedItem() == null || 
            lecturerComboBox.getSelectedItem().toString().equals("No lecturers available")) {
            JOptionPane.showMessageDialog(this, 
                "Please select a lecturer!", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (moduleField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Module field cannot be empty!", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (commentsArea.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please enter your comments/feedback!", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (commentsArea.getText().trim().length() < 10) {
            JOptionPane.showMessageDialog(this, 
                "Please provide more detailed feedback (at least 10 characters)!", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }
    
    /**
     * Clear all form fields
     */
    private void clearForm() {
        if (lecturerComboBox.getItemCount() > 0) {
            lecturerComboBox.setSelectedIndex(0);
        }
        ratingComboBox.setSelectedIndex(4);
        commentsArea.setText("");
    }
    
    /**
     * Handle button click events
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitBtn) {
            if (validateInput()) {
                // Create new feedback object
                String feedbackId = "FB" + System.currentTimeMillis();
                String studentId = currentStudent.getUserID();
                String studentName = currentStudent.getFullname();
                String lecturerName = lecturerComboBox.getSelectedItem().toString();
                String module = moduleField.getText().trim();
                int rating = (Integer) ratingComboBox.getSelectedItem();
                String comments = commentsArea.getText().trim();
                
                // Get current timestamp
                LocalDateTime now = LocalDateTime.now();
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                String timestamp = now.format(formatter);
                
                // Create StudentFeedback object - dedicated class for student feedback
                StudentFeedback feedback = new StudentFeedback(
                    feedbackId,
                    studentId,
                    studentName,
                    lecturerName,
                    module,
                    rating,
                    comments,
                    timestamp
                );
                
                // Add to DataIO
                DataIO.allStudentFeedback.add(feedback);
                
                // Save to file
                DataIO.write();
                
                JOptionPane.showMessageDialog(this,
                    "Thank you! Your feedback has been submitted successfully.\n" +
                    "The lecturer will review your comments.",
                    "Feedback Submitted",
                    JOptionPane.INFORMATION_MESSAGE);
                
                // Clear form
                clearForm();
            }
            
        } else if (e.getSource() == clearBtn) {
            int choice = JOptionPane.showConfirmDialog(this,
                "Clear all fields?",
                "Confirm Clear",
                JOptionPane.YES_NO_OPTION);
            
            if (choice == JOptionPane.YES_OPTION) {
                clearForm();
            }
            
        } else if (e.getSource() == backBtn) {
            // Return to student dashboard
            this.setVisible(false);
            Assignment.third = new StudentPage();
            Assignment.third.setVisible(true);
        }
    }
}
