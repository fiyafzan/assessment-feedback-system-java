package StudentGUI;

import MainClass.Assignment;
import Classes.AssessmentAss;
import Classes.DataIO;
import Classes.Student;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Check Results page for students
 * Allows students to view their assessment results and grades
 * Demonstrates: Data retrieval, Table display, Object relationships
 */
public class CheckResults extends JFrame implements ActionListener {
    
    // GUI Components
    private JPanel headerPanel;
    private JPanel infoPanel;
    private JPanel tablePanel;
    private JPanel statsPanel;
    private JPanel buttonPanel;
    
    private JLabel titleLabel;
    private JLabel studentNameLabel;
    private JLabel studentIdLabel;
    private JLabel moduleLabel;
    
    private JTable resultsTable;
    private DefaultTableModel tableModel;
    private JScrollPane scrollPane;
    
    private JLabel totalAssessmentsLabel;
    private JLabel averageScoreLabel;
    private JLabel overallGradeLabel;
    
    private JButton refreshBtn;
    private JButton backBtn;
    
    private Student currentStudent;
    
    public CheckResults() {
        currentStudent = Assignment.loginStudent;
        initComponents();
        loadResults();
        calculateStatistics();
    }
    
    /**
     * Initialize all GUI components
     */
    private void initComponents() {
        // Frame settings
        setTitle("Check Results - Student");
        setSize(800, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(247, 247, 247));
        
        // Header Panel
        headerPanel = new JPanel();
        headerPanel.setBackground(new Color(220, 20, 60));
        headerPanel.setBorder(BorderFactory.createMatteBorder(0, 3, 3, 0, new Color(180, 0, 40)));
        headerPanel.setPreferredSize(new Dimension(800, 80));
        headerPanel.setLayout(new GridBagLayout());
        
        titleLabel = new JLabel("My Assessment Results");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(new Color(255, 255, 153));
        headerPanel.add(titleLabel);
        
        // Student Info Panel
        infoPanel = new JPanel();
        infoPanel.setLayout(new GridLayout(3, 1, 5, 5));
        infoPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(15, 40, 10, 40),
            BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(70, 130, 180), 2),
                "Student Information",
                0,
                0,
                new Font("Arial", Font.BOLD, 14),
                new Color(70, 130, 180)
            )
        ));
        infoPanel.setBackground(new Color(247, 247, 247));
        
        if (currentStudent != null) {
            studentNameLabel = new JLabel("Name: " + currentStudent.getFullname());
            studentIdLabel = new JLabel("Student ID: " + currentStudent.getUserID());
            moduleLabel = new JLabel("Module: " + (currentStudent.getModule() != null ? currentStudent.getModule() : "Not registered"));
        } else {
            studentNameLabel = new JLabel("Name: N/A");
            studentIdLabel = new JLabel("Student ID: N/A");
            moduleLabel = new JLabel("Module: N/A");
        }
        
        studentNameLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        studentIdLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        moduleLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        
        infoPanel.add(studentNameLabel);
        infoPanel.add(studentIdLabel);
        infoPanel.add(moduleLabel);
        
        // Table Panel
        tablePanel = new JPanel();
        tablePanel.setLayout(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 10, 40));
        tablePanel.setBackground(new Color(247, 247, 247));
        
        // Create table
        String[] columnNames = {"Assessment Type", "Module", "Marks Obtained", "Total Marks", "Percentage", "Grade"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table read-only
            }
        };
        
        resultsTable = new JTable(tableModel);
        resultsTable.setFont(new Font("Arial", Font.PLAIN, 12));
        resultsTable.setRowHeight(30);
        resultsTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        resultsTable.getTableHeader().setBackground(new Color(70, 130, 180));
        resultsTable.getTableHeader().setForeground(Color.WHITE);
        
        scrollPane = new JScrollPane(resultsTable);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Statistics Panel
        statsPanel = new JPanel();
        statsPanel.setLayout(new GridLayout(1, 3, 20, 0));
        statsPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 10, 40));
        statsPanel.setBackground(new Color(247, 247, 247));
        
        totalAssessmentsLabel = createStatLabel("Total Assessments: 0", new Color(70, 130, 180));
        averageScoreLabel = createStatLabel("Average Score: 0%", new Color(34, 139, 34));
        overallGradeLabel = createStatLabel("Overall Grade: N/A", new Color(255, 140, 0));
        
        statsPanel.add(totalAssessmentsLabel);
        statsPanel.add(averageScoreLabel);
        statsPanel.add(overallGradeLabel);
        
        // Button Panel
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(new Color(247, 247, 247));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 20, 40));
        
        refreshBtn = new JButton("Refresh Results");
        refreshBtn.setFont(new Font("Arial", Font.BOLD, 14));
        refreshBtn.setBackground(new Color(70, 130, 180));
        refreshBtn.setForeground(Color.WHITE);
        refreshBtn.setFocusPainted(false);
        refreshBtn.setPreferredSize(new Dimension(160, 40));
        refreshBtn.addActionListener(this);
        
        backBtn = new JButton("Back to Dashboard");
        backBtn.setFont(new Font("Arial", Font.BOLD, 14));
        backBtn.setBackground(new Color(200, 200, 200));
        backBtn.setForeground(Color.BLACK);
        backBtn.setFocusPainted(false);
        backBtn.setPreferredSize(new Dimension(180, 40));
        backBtn.addActionListener(this);
        
        buttonPanel.add(refreshBtn);
        buttonPanel.add(backBtn);
        
        // Create main content panel
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBackground(new Color(247, 247, 247));
        contentPanel.add(infoPanel, BorderLayout.NORTH);
        contentPanel.add(tablePanel, BorderLayout.CENTER);
        contentPanel.add(statsPanel, BorderLayout.SOUTH);
        
        // Add panels to frame
        add(headerPanel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    /**
     * Helper method to create styled stat labels
     */
    private JLabel createStatLabel(String text, Color color) {
        JLabel label = new JLabel(text, SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        label.setOpaque(true);
        label.setBackground(color);
        label.setForeground(Color.WHITE);
        label.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color.darker(), 2),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        return label;
    }
    
    /**
     * Load student results from DataIO
     */
    private void loadResults() {
        // Clear existing rows
        tableModel.setRowCount(0);
        
        if (currentStudent == null) {
            return;
        }
        
        String studentName = currentStudent.getFullname();
        
        // Load assessments for this student
        if (DataIO.allAssessment != null && !DataIO.allAssessment.isEmpty()) {
            for (AssessmentAss assessment : DataIO.allAssessment) {
                if (assessment.getStudentName() != null && assessment.getStudentName().equals(studentName)) {
                    // Get assessment type details for max marks
                    int maxMarks = 100; // default
                    for (Classes.AssessmentTypeAss type : DataIO.allAssessmentType) {
                        if (type.getModule().equals(assessment.getModule()) && 
                            type.getAssessmentType().equals(assessment.getAssessmentType())) {
                            break;
                        }
                    }
                    
                    // Calculate percentage and grade
                    int marksObtained = assessment.getMark();
                    double percentage = (double) marksObtained / maxMarks * 100;
                    String grade = calculateGrade(percentage);
                    
                    Object[] row = {
                        assessment.getAssessmentType(),
                        assessment.getModule(),
                        String.valueOf(marksObtained),
                        String.valueOf(maxMarks),
                        String.format("%.2f%%", percentage),
                        grade
                    };
                    tableModel.addRow(row);
                }
            }
        }
        
        // If no results found
        if (tableModel.getRowCount() == 0) {
            JLabel noDataLabel = new JLabel("No assessment results available yet");
            noDataLabel.setFont(new Font("Arial", Font.ITALIC, 14));
            noDataLabel.setForeground(Color.GRAY);
            noDataLabel.setHorizontalAlignment(SwingConstants.CENTER);
            
            tablePanel.removeAll();
            tablePanel.add(noDataLabel, BorderLayout.CENTER);
            tablePanel.revalidate();
            tablePanel.repaint();
        }
    }
    
    /**
     * Calculate grade based on percentage
     */
    private String calculateGrade(double percentage) {
        if (percentage >= 85) return "A";
        else if (percentage >= 75) return "A-";
        else if (percentage >= 70) return "B+";
        else if (percentage >= 65) return "B";
        else if (percentage >= 60) return "B-";
        else if (percentage >= 55) return "C+";
        else if (percentage >= 50) return "C";
        else if (percentage >= 45) return "D";
        else return "F";
    }
    
    /**
     * Calculate and display statistics
     */
    private void calculateStatistics() {
        int totalAssessments = tableModel.getRowCount();
        totalAssessmentsLabel.setText("Total Assessments: " + totalAssessments);
        
        if (totalAssessments > 0) {
            double totalPercentage = 0;
            
            for (int i = 0; i < totalAssessments; i++) {
                String percentageStr = (String) tableModel.getValueAt(i, 4);
                // Remove the % sign and parse
                percentageStr = percentageStr.replace("%", "");
                try {
                    totalPercentage += Double.parseDouble(percentageStr);
                } catch (NumberFormatException e) {
                    // Skip this row
                }
            }
            
            double average = totalPercentage / totalAssessments;
            averageScoreLabel.setText(String.format("Average Score: %.2f%%", average));
            overallGradeLabel.setText("Overall Grade: " + calculateGrade(average));
        } else {
            averageScoreLabel.setText("Average Score: 0%");
            overallGradeLabel.setText("Overall Grade: N/A");
        }
    }
    
    /**
     * Handle button click events
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == refreshBtn) {
            // Reload results
            loadResults();
            calculateStatistics();
            JOptionPane.showMessageDialog(this,
                "Results refreshed!",
                "Refresh Complete",
                JOptionPane.INFORMATION_MESSAGE);
            
        } else if (e.getSource() == backBtn) {
            // Return to student dashboard
            this.setVisible(false);
            Assignment.third = new StudentPage();
            Assignment.third.setVisible(true);
        }
    }
}
