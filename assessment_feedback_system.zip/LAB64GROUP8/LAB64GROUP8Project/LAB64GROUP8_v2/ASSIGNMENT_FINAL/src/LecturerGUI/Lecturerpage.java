
package LecturerGUI;

import MainClass.Assignment;
import Classes.Lecturer;
import javax.swing.BorderFactory;
import javax.swing.JLabel;


public class Lecturerpage extends javax.swing.JFrame {
    
    
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Lecturerpage.class.getName());

    public Lecturerpage() {
        initComponents();
        setupHeader();
    }
    
    
    public void setupHeader() {
        Lecturer lec = Assignment.loginLecturer;
        if (lec != null && lec.getFullname() != null) {
            welcomelabel.setText("Welcome, Dr. " + lec.getFullname());
        } else {
            welcomelabel.setText("Welcome, Dr.");
        }
    }


    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBox1 = new javax.swing.JCheckBox();
        headerpanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        welcomelabel = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        LectName = new javax.swing.JLabel();
        BackBtn = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        Editbtn = new javax.swing.JButton();
        DesignAssBtn = new javax.swing.JButton();
        KeyinBtn = new javax.swing.JButton();
        FeedBtn = new javax.swing.JButton();

        jCheckBox1.setText("jCheckBox1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(247, 247, 247));
        setResizable(false);
        setSize(new java.awt.Dimension(500, 200));

        headerpanel.setBackground(new java.awt.Color(255, 140, 0));
        headerpanel.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 3, 3, 0, new java.awt.Color(230, 120, 0)));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 153));
        jLabel1.setText("Lecturer Dashboard");

        welcomelabel.setForeground(new java.awt.Color(255, 255, 255));
        welcomelabel.setText("Welcome, Dr.");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));

        LectName.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        LectName.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout headerpanelLayout = new javax.swing.GroupLayout(headerpanel);
        headerpanel.setLayout(headerpanelLayout);
        headerpanelLayout.setHorizontalGroup(
            headerpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerpanelLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(headerpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(headerpanelLayout.createSequentialGroup()
                        .addComponent(welcomelabel, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(LectName, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        headerpanelLayout.setVerticalGroup(
            headerpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerpanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(headerpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addGroup(headerpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(welcomelabel)
                        .addComponent(LectName))))
        );

        BackBtn.setText("Logout");
        BackBtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, new java.awt.Color(255, 153, 102), new java.awt.Color(255, 153, 102), java.awt.Color.orange));
        BackBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackBtnActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 153, 102), java.awt.Color.orange));

        Editbtn.setLabel("Edit Profile");
        Editbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditbtnActionPerformed(evt);
            }
        });

        DesignAssBtn.setLabel("Design Assessment Type");
        DesignAssBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DesignAssBtnActionPerformed(evt);
            }
        });

        KeyinBtn.setLabel("Key-In Mark");
        KeyinBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeyinBtnActionPerformed(evt);
            }
        });

        FeedBtn.setLabel("Provide Feedback");
        FeedBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FeedBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Editbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DesignAssBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 299, Short.MAX_VALUE)
                    .addComponent(KeyinBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(FeedBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(Editbtn)
                .addGap(31, 31, 31)
                .addComponent(DesignAssBtn)
                .addGap(27, 27, 27)
                .addComponent(KeyinBtn)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addComponent(FeedBtn)
                .addGap(24, 24, 24))
        );

        Editbtn.getAccessibleContext().setAccessibleName("EditProfilBtn");
        DesignAssBtn.getAccessibleContext().setAccessibleName("DesignAssTypeBtn");
        KeyinBtn.getAccessibleContext().setAccessibleName("KeyInMarkBtn");
        FeedBtn.getAccessibleContext().setAccessibleName("FeedbackBtn");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(BackBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(headerpanel, javax.swing.GroupLayout.PREFERRED_SIZE, 359, Short.MAX_VALUE))
                .addContainerGap(62, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(headerpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(BackBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(58, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void EditbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditbtnActionPerformed
        new EditProfileAss().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_EditbtnActionPerformed

    private void DesignAssBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DesignAssBtnActionPerformed
        new DesignAss().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_DesignAssBtnActionPerformed

    private void KeyinBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeyinBtnActionPerformed
        new KeyInMarkAss().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeyinBtnActionPerformed

    private void FeedBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FeedBtnActionPerformed
        new Feedback().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_FeedBtnActionPerformed

    private void BackBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackBtnActionPerformed
         Assignment.one.x.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackBtnActionPerformed


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> new Lecturerpage().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackBtn;
    private javax.swing.JButton DesignAssBtn;
    private javax.swing.JButton Editbtn;
    private javax.swing.JButton FeedBtn;
    private javax.swing.JButton KeyinBtn;
    private javax.swing.JLabel LectName;
    private javax.swing.JPanel headerpanel;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel welcomelabel;
    // End of variables declaration//GEN-END:variables
}
