
package LecturerGUI;
import Classes.Module;
import Classes.AssessmentTypeAss;
import MainClass.Assignment;
import Classes.DataIO;
import Classes.Lecturer;
import java.io.File;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class DesignAss extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(DesignAss.class.getName());

    public DesignAss() {
        initComponents();
        loadModuleCombo();
    
    }

     private void saveAssessmentType() {
        try {
            String module = (String) ModuleComb.getSelectedItem();
            String assessmentType = (String) AssTypeComb.getSelectedItem();
            String weightageText = WeightageTB.getText().trim();
            String maxMarkText = MaxMarkTB.getText().trim();
            
            if (weightageText.isEmpty() || maxMarkText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields");
                return;
            }
            
            int weightage = Integer.parseInt(weightageText);
            int maxMark = Integer.parseInt(maxMarkText);
            
            if (weightage <= 0 || weightage > 100) {
                JOptionPane.showMessageDialog(this, "Weightage must be between 1-100");
                return;
            }
            
            if (maxMark <= 0) {
                JOptionPane.showMessageDialog(this, "Max Mark must be greater than 0");
                return;
            }
            
            
            
            AssessmentTypeAss newAssessment = new AssessmentTypeAss(module, assessmentType, weightage, maxMark);
            
            DataIO.allAssessmentType.add(newAssessment);
            DataIO.write();
            
            
            WeightageTB.setText("");
            MaxMarkTB.setText("");
            
            JOptionPane.showMessageDialog(this, "Assessment Type saved successfully!");
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers");
        }
    }
     
     
    private void loadModuleCombo() {
    ModuleComb.removeAllItems();

    Lecturer lec = Assignment.loginLecturer;
    String lecturerModule = lec.getModule();

    if (lecturerModule == null || lecturerModule.isEmpty()) return;

    String[] lecturerModules = lecturerModule.split(",");

    for (Module m : DataIO.allModules) {
        for (String lm : lecturerModules) {
            if (m.getModuleName().equals(lm.trim())) {
                ModuleComb.addItem(m.getModuleName());
            }
        }
    }
}

   //private void loadModuleCombo() {
    //try {
    //    ModuleComb.removeAllItems();  // Clear existing items
        
    //    Scanner s = new Scanner(new File("module.txt"));
    //    while(s.hasNextLine()) {
    //        String module = s.nextLine().trim();  // Read each line
    //        if(!module.isEmpty()) {  // Skip empty lines
    //            ModuleComb.addItem(module);  // Add to combobox
    //        }
    //    }
    //    s.close();
        
    //} catch(Exception e) {
    //    System.out.println("Error loading modules from file");
    //}}
     
     
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        label1 = new java.awt.Label();
        jPanel5 = new javax.swing.JPanel();
        EditBtn = new javax.swing.JButton();
        DesignBtn = new javax.swing.JButton();
        KeyinBtn = new javax.swing.JButton();
        FeedBtn = new javax.swing.JButton();
        BackBtn1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        SaveBtn = new javax.swing.JButton();
        ModuleComb = new javax.swing.JComboBox<>();
        AssTypeComb = new javax.swing.JComboBox<>();
        WeightageTB = new javax.swing.JTextField();
        MaxMarkTB = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 140, 0));
        setForeground(java.awt.Color.white);
        setSize(new java.awt.Dimension(500, 200));

        label1.setFont(new java.awt.Font("Arial Black", 0, 30)); // NOI18N
        label1.setPreferredSize(new java.awt.Dimension(50, 20));
        label1.setText("Design Asssesment Type");

        jPanel5.setBackground(new java.awt.Color(255, 140, 0));

        EditBtn.setLabel("Edit Profile");
        EditBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditBtnActionPerformed(evt);
            }
        });

        DesignBtn.setLabel("Design Assessment Type");
        DesignBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DesignBtnActionPerformed(evt);
            }
        });

        KeyinBtn.setLabel("Key-In Mark");
        KeyinBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeyinBtnActionPerformed(evt);
            }
        });

        FeedBtn.setLabel("Provide Feedback");
        FeedBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FeedBtnActionPerformed(evt);
            }
        });

        BackBtn1.setText("Homepage");
        BackBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackBtn1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(KeyinBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DesignBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(EditBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(FeedBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
                    .addComponent(BackBtn1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(38, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(115, 115, 115)
                .addComponent(EditBtn)
                .addGap(31, 31, 31)
                .addComponent(DesignBtn)
                .addGap(30, 30, 30)
                .addComponent(KeyinBtn)
                .addGap(30, 30, 30)
                .addComponent(FeedBtn)
                .addGap(30, 30, 30)
                .addComponent(BackBtn1)
                .addContainerGap(71, Short.MAX_VALUE))
        );

        EditBtn.getAccessibleContext().setAccessibleName("EditProfilBtn");
        DesignBtn.getAccessibleContext().setAccessibleName("DesignAssTypeBtn");
        KeyinBtn.getAccessibleContext().setAccessibleName("KeyInMarkBtn");
        FeedBtn.getAccessibleContext().setAccessibleName("FeedbackBtn");

        jLabel1.setText("Select Module:");

        jLabel2.setText("Assessment Type:");

        jLabel3.setText("Weightage (%):");

        jLabel4.setText("Max Mark:");

        SaveBtn.setText("Save");
        SaveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveBtnActionPerformed(evt);
            }
        });

        ModuleComb.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "OODJ", "SRE", "SNA ", "CTF" }));
        ModuleComb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModuleCombActionPerformed(evt);
            }
        });

        AssTypeComb.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Assignment", "Quiz", "Test", "Final" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(79, 79, 79)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 424, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(34, 34, 34)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(WeightageTB)
                            .addComponent(MaxMarkTB)
                            .addComponent(ModuleComb, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(AssTypeComb, 0, 239, Short.MAX_VALUE)
                            .addComponent(SaveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(41, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(ModuleComb, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(AssTypeComb, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(WeightageTB, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(MaxMarkTB, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(SaveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void EditBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditBtnActionPerformed
        new EditProfileAss().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_EditBtnActionPerformed

    private void DesignBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DesignBtnActionPerformed
        new DesignAss().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_DesignBtnActionPerformed

    private void KeyinBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeyinBtnActionPerformed
        new KeyInMarkAss().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeyinBtnActionPerformed

    private void FeedBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FeedBtnActionPerformed
        new Feedback().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_FeedBtnActionPerformed

    private void SaveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveBtnActionPerformed
        saveAssessmentType();
    }//GEN-LAST:event_SaveBtnActionPerformed

    private void ModuleCombActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModuleCombActionPerformed
        
    }//GEN-LAST:event_ModuleCombActionPerformed

    private void BackBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackBtn1ActionPerformed
        new Lecturerpage().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackBtn1ActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> new DesignAss().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> AssTypeComb;
    private javax.swing.JButton BackBtn1;
    private javax.swing.JButton DesignBtn;
    private javax.swing.JButton EditBtn;
    private javax.swing.JButton FeedBtn;
    private javax.swing.JButton KeyinBtn;
    private javax.swing.JTextField MaxMarkTB;
    private javax.swing.JComboBox<String> ModuleComb;
    private javax.swing.JButton SaveBtn;
    private javax.swing.JTextField WeightageTB;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel5;
    private java.awt.Label label1;
    // End of variables declaration//GEN-END:variables
}
