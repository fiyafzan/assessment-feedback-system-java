
package LecturerGUI;
import Classes.AssessmentAss;
import Classes.AssessmentTypeAss;
import MainClass.Assignment;
import Classes.DataIO;
import Classes.Lecturer;
import Classes.Module;
import Classes.Student;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class KeyInMarkAss extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(KeyInMarkAss.class.getName());

    public KeyInMarkAss() {
        initComponents();
        loadModuleCombo();
        loadStudentNameCombo();
        loadAssessmentTypeCombo();
    }
    
    private void loadModuleCombo() {
    ModuleComb.removeAllItems();

    Lecturer lec = Assignment.loginLecturer;
    String lecturerModule = lec.getModule();

    if (lecturerModule == null || lecturerModule.isEmpty()) return;

    String[] lecturerModules = lecturerModule.split(",");

    for (Module m : DataIO.allModules) {
        for (String lm : lecturerModules) {
            if (m.getModuleName().equals(lm.trim())) {
                ModuleComb.addItem(m.getModuleName());
            }
        }
    }
}

    
    private void loadAssessmentTypeCombo() {
    AssTypeComb.removeAllItems();

    String selectedModule = (String) ModuleComb.getSelectedItem();
    if (selectedModule == null) return;

    ArrayList<String> addedTypes = new ArrayList<>();

    for (AssessmentTypeAss x : DataIO.allAssessmentType) {
        if (x.getModule().equalsIgnoreCase(selectedModule)) {
            String type = x.getAssessmentType();
            if (!addedTypes.contains(type)) {
                AssTypeComb.addItem(type);
                addedTypes.add(type);
            }
        }
    }
}

    
    private void loadStudentNameCombo() {
    StudentComb.removeAllItems();

    String selectedModule = (String) ModuleComb.getSelectedItem();
    if (selectedModule == null) return;

    for (Student s : DataIO.allStudent) {
        if (s.getModule().equalsIgnoreCase(selectedModule)) {
            StudentComb.addItem(s.getFullname());
        }
    }
}


    
    private void saveAssessment() {
    try {
        String selectedModule = (String) ModuleComb.getSelectedItem();
        String selectedAssessmentType = (String) AssTypeComb.getSelectedItem();
        String selectedStudentName = (String) StudentComb.getSelectedItem();
        String marksText = markTB.getText().trim();
        
        // Validation
        if (selectedModule == null) {
            JOptionPane.showMessageDialog(this, "Please select a module!");
            return;
        }
        
        if (selectedAssessmentType == null) {
            JOptionPane.showMessageDialog(this, "Please select an assessment type!");
            return;
        }
        
        if (selectedStudentName == null) {
            JOptionPane.showMessageDialog(this, "Please select a student name!");
            return;
        }
        
        if (marksText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter marks!");
            return;
        }
        
        int marks = Integer.parseInt(marksText);
        
        if (marks < 0 || marks > 100) {
            JOptionPane.showMessageDialog(this, "Marks must be between 0 and 100!");
            return;
        }
        
        AssessmentAss newAssessment = new AssessmentAss(selectedModule, selectedAssessmentType, selectedStudentName, marks);
        DataIO.allAssessment.add(newAssessment);
        DataIO.write();
        
        JOptionPane.showMessageDialog(this, "Assessment saved successfully!");
        
        // Clear fields
        ModuleComb.setSelectedItem(null);
        AssTypeComb.setSelectedItem(null);
        StudentComb.setSelectedItem(null);
        markTB.setText("");

        
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Please enter a valid number for marks!");
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        label1 = new java.awt.Label();
        jPanel5 = new javax.swing.JPanel();
        EditBtn = new javax.swing.JButton();
        DesignBtn = new javax.swing.JButton();
        KeyInBtn = new javax.swing.JButton();
        FeedBtn = new javax.swing.JButton();
        BackBtn1 = new javax.swing.JButton();
        BackBtn = new javax.swing.JButton();
        ModuleComb = new javax.swing.JComboBox<>();
        AssTypeComb = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        SaveBtn1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        StudentLbl = new javax.swing.JLabel();
        StudentComb = new javax.swing.JComboBox<>();
        markTB = new java.awt.TextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 140, 0));
        setForeground(java.awt.Color.white);
        setSize(new java.awt.Dimension(500, 200));

        label1.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        label1.setPreferredSize(new java.awt.Dimension(50, 20));
        label1.setText("Key-In Mark");

        jPanel5.setBackground(new java.awt.Color(255, 140, 0));

        EditBtn.setLabel("Edit Profile");
        EditBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditBtnActionPerformed(evt);
            }
        });

        DesignBtn.setLabel("Design Assessment Type");
        DesignBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DesignBtnActionPerformed(evt);
            }
        });

        KeyInBtn.setLabel("Key-In Mark");
        KeyInBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeyInBtnActionPerformed(evt);
            }
        });

        FeedBtn.setLabel("Provide Feedback");
        FeedBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FeedBtnActionPerformed(evt);
            }
        });

        BackBtn1.setText("Homepage");
        BackBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackBtn1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BackBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(KeyInBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(DesignBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addComponent(EditBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(FeedBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)))
                .addContainerGap(54, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(99, 99, 99)
                .addComponent(EditBtn)
                .addGap(30, 30, 30)
                .addComponent(DesignBtn)
                .addGap(30, 30, 30)
                .addComponent(KeyInBtn)
                .addGap(30, 30, 30)
                .addComponent(FeedBtn)
                .addGap(30, 30, 30)
                .addComponent(BackBtn1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        EditBtn.getAccessibleContext().setAccessibleName("EditProfilBtn");
        DesignBtn.getAccessibleContext().setAccessibleName("DesignAssTypeBtn");
        KeyInBtn.getAccessibleContext().setAccessibleName("KeyInMarkBtn");
        FeedBtn.getAccessibleContext().setAccessibleName("FeedbackBtn");

        BackBtn.setText("Back");
        BackBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackBtnActionPerformed(evt);
            }
        });

        ModuleComb.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        ModuleComb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModuleCombActionPerformed(evt);
            }
        });

        AssTypeComb.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel1.setText("Select Module:");

        jLabel2.setText("Assessment Type:");

        SaveBtn1.setText("Save");
        SaveBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveBtn1ActionPerformed(evt);
            }
        });

        jLabel3.setText("Marks:");

        StudentLbl.setText("Student Name:");

        StudentComb.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(65, 65, 65)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(label1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(StudentLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGap(34, 34, 34)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(ModuleComb, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(AssTypeComb, 0, 239, Short.MAX_VALUE)
                                .addComponent(StudentComb, 0, 239, Short.MAX_VALUE)
                                .addComponent(markTB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(SaveBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(55, 55, 55)
                        .addComponent(BackBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 84, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(ModuleComb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(AssTypeComb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(StudentLbl)
                    .addComponent(StudentComb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(markTB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SaveBtn1)
                    .addComponent(BackBtn))
                .addContainerGap(40, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void EditBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditBtnActionPerformed
        new EditProfileAss().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_EditBtnActionPerformed

    private void DesignBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DesignBtnActionPerformed
        new DesignAss().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_DesignBtnActionPerformed

    private void KeyInBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeyInBtnActionPerformed
        new KeyInMarkAss().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeyInBtnActionPerformed

    private void FeedBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FeedBtnActionPerformed
        new Feedback().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_FeedBtnActionPerformed

    private void ModuleCombActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModuleCombActionPerformed
        loadStudentNameCombo();
        loadAssessmentTypeCombo();
    }//GEN-LAST:event_ModuleCombActionPerformed

    private void BackBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackBtnActionPerformed
        Assignment.one.x.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackBtnActionPerformed

    private void BackBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackBtn1ActionPerformed
        new Lecturerpage().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackBtn1ActionPerformed

    private void SaveBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveBtn1ActionPerformed
        saveAssessment();
    }//GEN-LAST:event_SaveBtn1ActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> new KeyInMarkAss().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> AssTypeComb;
    private javax.swing.JButton BackBtn;
    private javax.swing.JButton BackBtn1;
    private javax.swing.JButton DesignBtn;
    private javax.swing.JButton EditBtn;
    private javax.swing.JButton FeedBtn;
    private javax.swing.JButton KeyInBtn;
    private javax.swing.JComboBox<String> ModuleComb;
    private javax.swing.JButton SaveBtn1;
    private javax.swing.JComboBox<String> StudentComb;
    private javax.swing.JLabel StudentLbl;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel5;
    private java.awt.Label label1;
    private java.awt.TextField markTB;
    // End of variables declaration//GEN-END:variables
}
