
package LecturerGUI;

import MainClass.Assignment;
import Classes.DataIO;
import Classes.Lecturer;
import javax.swing.JOptionPane;


public class EditProfileAss extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(EditProfileAss.class.getName());

    
    public EditProfileAss() {
        initComponents();
        loadlecturerData();
        
        userIDTB.setEditable(false);
        acleadTB.setEditable(false);
        moduleTB.setEditable(false);
    }
    
    private void loadlecturerData(){
        Lecturer lecturer = Assignment.loginLecturer;
        
        userIDTB.setText(lecturer.getUserID());
        usernameTB.setText(lecturer.getUsername());
        fullnameTB.setText(lecturer.getFullname());
        emailTB.setText(lecturer.getEmail());
        AgeTB.setText(lecturer.getAge());
        acleadTB.setText(lecturer.getAssignedTo());
        moduleTB.setText(lecturer.getModule());
        passTB.setText(lecturer.getPassword());
        phoneTB.setText(lecturer.getPhone());
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        label1 = new java.awt.Label();
        jPanel5 = new javax.swing.JPanel();
        EditprofBtn = new javax.swing.JButton();
        DesignassBtn = new javax.swing.JButton();
        KeyinBtn = new javax.swing.JButton();
        FeedBtn = new javax.swing.JButton();
        BackBtn1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        userIDTB = new java.awt.TextField();
        moduleTB = new java.awt.TextField();
        usernameTB = new java.awt.TextField();
        acleadTB = new java.awt.TextField();
        emailTB = new java.awt.TextField();
        passTB = new java.awt.TextField();
        phoneTB = new java.awt.TextField();
        SaveButton = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        fullnameTB = new java.awt.TextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        AgeTB = new java.awt.TextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 140, 0));
        setForeground(java.awt.Color.white);
        setSize(new java.awt.Dimension(500, 200));

        label1.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        label1.setPreferredSize(new java.awt.Dimension(50, 20));
        label1.setText("Edit profile");

        jPanel5.setBackground(new java.awt.Color(255, 140, 0));

        EditprofBtn.setLabel("Edit Profile");
        EditprofBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditprofBtnActionPerformed(evt);
            }
        });

        DesignassBtn.setLabel("Design Assessment Type");
        DesignassBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DesignassBtnActionPerformed(evt);
            }
        });

        KeyinBtn.setLabel("Key-In Mark");
        KeyinBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeyinBtnActionPerformed(evt);
            }
        });

        FeedBtn.setLabel("Provide Feedback");
        FeedBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FeedBtnActionPerformed(evt);
            }
        });

        BackBtn1.setText("Homepage");
        BackBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackBtn1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(KeyinBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DesignassBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(EditprofBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(FeedBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
                    .addComponent(BackBtn1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(38, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(115, 115, 115)
                .addComponent(EditprofBtn)
                .addGap(30, 30, 30)
                .addComponent(DesignassBtn)
                .addGap(30, 30, 30)
                .addComponent(KeyinBtn)
                .addGap(31, 31, 31)
                .addComponent(FeedBtn)
                .addGap(30, 30, 30)
                .addComponent(BackBtn1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        EditprofBtn.getAccessibleContext().setAccessibleName("EditProfilBtn");
        DesignassBtn.getAccessibleContext().setAccessibleName("DesignAssTypeBtn");
        KeyinBtn.getAccessibleContext().setAccessibleName("KeyInMarkBtn");
        FeedBtn.getAccessibleContext().setAccessibleName("FeedbackBtn");

        jLabel1.setText("Full name:");

        jLabel2.setText("Password:");
        jLabel2.setToolTipText("Username");

        jLabel3.setText("Username:");
        jLabel3.setToolTipText("Username");

        jLabel4.setText("Email:");
        jLabel4.setToolTipText("Username");

        jLabel6.setText("Academic Leader:");
        jLabel6.setToolTipText("Username");

        jLabel7.setText("Module:");
        jLabel7.setToolTipText("Username");

        userIDTB.setName("FullNameTB"); // NOI18N
        userIDTB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userIDTBActionPerformed(evt);
            }
        });

        moduleTB.setName("PassTB"); // NOI18N

        usernameTB.setName("UsernameTB"); // NOI18N
        usernameTB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usernameTBActionPerformed(evt);
            }
        });

        acleadTB.setName("NumberTB"); // NOI18N

        emailTB.setName("EmailTB"); // NOI18N
        emailTB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailTBActionPerformed(evt);
            }
        });

        passTB.setName("AcLeaderTB"); // NOI18N
        passTB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passTBActionPerformed(evt);
            }
        });

        phoneTB.setName("ModuleTB"); // NOI18N

        SaveButton.setText("Save");
        SaveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveButtonActionPerformed(evt);
            }
        });

        jLabel8.setText("User ID:");

        fullnameTB.setName("FullNameTB"); // NOI18N
        fullnameTB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fullnameTBActionPerformed(evt);
            }
        });

        jLabel9.setText("Phone Number:");
        jLabel9.setToolTipText("Username");

        jLabel11.setText("Age:");
        jLabel11.setToolTipText("Username");

        AgeTB.setName("NumberTB"); // NOI18N
        AgeTB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgeTBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(jLabel1)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)
                            .addComponent(jLabel9))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(userIDTB, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(acleadTB, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(moduleTB, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(passTB, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(emailTB, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(usernameTB, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(fullnameTB, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(AgeTB, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(phoneTB, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(59, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(SaveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(165, 165, 165))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel8)
                    .addComponent(userIDTB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(usernameTB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(fullnameTB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(emailTB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(AgeTB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addGap(18, 18, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(passTB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(moduleTB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(acleadTB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(18, 18, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(phoneTB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addComponent(SaveButton)
                .addContainerGap())
        );

        jLabel1.getAccessibleContext().setAccessibleName("editnameLbl");
        jLabel2.getAccessibleContext().setAccessibleName("Passlbl");
        jLabel3.getAccessibleContext().setAccessibleName("Usernamelbl");
        jLabel4.getAccessibleContext().setAccessibleName("EmailLbl");
        jLabel6.getAccessibleContext().setAccessibleName("AcLeadLbl");
        jLabel7.getAccessibleContext().setAccessibleName("ModuleLbl");
        userIDTB.getAccessibleContext().setAccessibleName("FullNameTB");
        moduleTB.getAccessibleContext().setAccessibleName("PassTB");
        moduleTB.getAccessibleContext().setAccessibleDescription("");
        usernameTB.getAccessibleContext().setAccessibleName("UsernameTB");
        acleadTB.getAccessibleContext().setAccessibleName("NumberTB");
        emailTB.getAccessibleContext().setAccessibleName("EmailTB");
        passTB.getAccessibleContext().setAccessibleName("AcLeaderTB");
        phoneTB.getAccessibleContext().setAccessibleName("ModuleTB");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void EditprofBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditprofBtnActionPerformed
        new EditProfileAss().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_EditprofBtnActionPerformed

    private void DesignassBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DesignassBtnActionPerformed
        new DesignAss().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_DesignassBtnActionPerformed

    private void KeyinBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeyinBtnActionPerformed
        new KeyInMarkAss().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeyinBtnActionPerformed

    private void FeedBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FeedBtnActionPerformed
        new Feedback().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_FeedBtnActionPerformed

    private void SaveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveButtonActionPerformed
       
        try{
           
        Lecturer lecturer = Assignment.loginLecturer;
        
        String username = usernameTB.getText().trim();
        String password = passTB.getText().trim();
        String fullName = fullnameTB.getText().trim();
        String email = emailTB.getText().trim();
        String age = AgeTB.getText().trim();
        String phone = phoneTB.getText().trim();
        
        if (username.isEmpty() || password.isEmpty() || fullName.isEmpty() || 
                email.isEmpty() || phone.isEmpty() || age.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields");
                return;
            }
        
        if (!email.contains("@")) {
                JOptionPane.showMessageDialog(this, "Please enter a valid email");
                return;
            }
        
        lecturer.setUsername(username);
        lecturer.setPassword(password);
        lecturer.setFullname(fullName);
        lecturer.setEmail(email);
        lecturer.setAge(age);
        lecturer.setPhone(phone);
        
        DataIO.write();
        
        JOptionPane.showMessageDialog(this, "Profile updated successfully!");
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error updating profile: " + e.getMessage());
        }
    }//GEN-LAST:event_SaveButtonActionPerformed

    private void usernameTBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usernameTBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_usernameTBActionPerformed

    private void fullnameTBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fullnameTBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fullnameTBActionPerformed

    private void BackBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackBtn1ActionPerformed
        new Lecturerpage().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackBtn1ActionPerformed

    private void passTBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passTBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passTBActionPerformed

    private void emailTBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailTBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailTBActionPerformed

    private void userIDTBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userIDTBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_userIDTBActionPerformed

    private void AgeTBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgeTBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AgeTBActionPerformed

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(() -> new EditProfileAss().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.TextField AgeTB;
    private javax.swing.JButton BackBtn1;
    private javax.swing.JButton DesignassBtn;
    private javax.swing.JButton EditprofBtn;
    private javax.swing.JButton FeedBtn;
    private javax.swing.JButton KeyinBtn;
    private javax.swing.JButton SaveButton;
    private java.awt.TextField acleadTB;
    private java.awt.TextField emailTB;
    private java.awt.TextField fullnameTB;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel5;
    private java.awt.Label label1;
    private java.awt.TextField moduleTB;
    private java.awt.TextField passTB;
    private java.awt.TextField phoneTB;
    private java.awt.TextField userIDTB;
    private java.awt.TextField usernameTB;
    // End of variables declaration//GEN-END:variables
}
