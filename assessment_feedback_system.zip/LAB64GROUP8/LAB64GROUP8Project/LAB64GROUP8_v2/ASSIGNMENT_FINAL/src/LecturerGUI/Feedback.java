
package LecturerGUI;
import Classes.Module;
import Classes.AssessmentTypeAss;
import MainClass.Assignment;
import Classes.DataIO;
import Classes.FeedbackclassAss;
import Classes.Lecturer;
import Classes.Student;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Feedback extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Feedback.class.getName());

    
    public Feedback() {
        initComponents();
        loadModuleCombo();
        loadStudentNameCombo();
        loadAssessmentTypeCombo();


    }
    
    private void loadModuleCombo() {
    ModuleComb.removeAllItems();

    Lecturer lec = Assignment.loginLecturer;
    String lecturerModule = lec.getModule();

    if (lecturerModule == null || lecturerModule.isEmpty()) return;

    String[] lecturerModules = lecturerModule.split(",");

    for (Module m : DataIO.allModules) {
        for (String lm : lecturerModules) {
            if (m.getModuleName().equals(lm.trim())) {
                ModuleComb.addItem(m.getModuleName());
            }
        }
    }
}

    
    private void loadAssessmentTypeCombo() {
    AssTypeComb.removeAllItems();

    String selectedModule = (String) ModuleComb.getSelectedItem();
    if (selectedModule == null) return;

    ArrayList<String> addedTypes = new ArrayList<>();

    for (AssessmentTypeAss x : DataIO.allAssessmentType) {
        if (x.getModule().equalsIgnoreCase(selectedModule)) {
            String type = x.getAssessmentType();
            if (!addedTypes.contains(type)) {
                AssTypeComb.addItem(type);
                addedTypes.add(type);
            }
        }
    }
}

    
    private void loadStudentNameCombo() {
    StudentComb.removeAllItems();

    String selectedModule = (String) ModuleComb.getSelectedItem();
    if (selectedModule == null) return;

    for (Student s : DataIO.allStudent) {
        if (s.getModule().equalsIgnoreCase(selectedModule)) {
            StudentComb.addItem(s.getFullname());
        }
    }
}


    

private void saveFeedback() {
    try {
        String selectedModule = (String) ModuleComb.getSelectedItem();
        String selectedStudentName = (String) StudentComb.getSelectedItem();
        String selectedAssessmentType = (String) AssTypeComb.getSelectedItem();
        String feedbackText = FeedbackTA.getText().trim();
        
        // Validation
        if (selectedModule == null) {
            JOptionPane.showMessageDialog(this, "Please select a module!");
            return;
        }
        
        if (selectedStudentName == null) {
            JOptionPane.showMessageDialog(this, "Please select a student name!");
            return;
        }
        
        if (selectedAssessmentType == null) {
            JOptionPane.showMessageDialog(this, "Please select an assessment type!");
            return;
        }
        
        if (feedbackText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter feedback!");
            return;
        }
        
        // Create new Feedbackclass object and add to ArrayList
        FeedbackclassAss newFeedback = new FeedbackclassAss(selectedModule, selectedStudentName, selectedAssessmentType, feedbackText);
        DataIO.allFeedback.add(newFeedback);
        
        // Write to file
        DataIO.write();
        
        // Show success message
        JOptionPane.showMessageDialog(this, "Feedback saved successfully!");
        
        // Clear fields
        ModuleComb.setSelectedItem(null);
        StudentComb.setSelectedItem(null);
        AssTypeComb.setSelectedItem(null);
        FeedbackTA.setText("");

        
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error saving feedback: " + e.getMessage());
        e.printStackTrace();
    }
}
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        label1 = new java.awt.Label();
        jPanel5 = new javax.swing.JPanel();
        EditBtn = new javax.swing.JButton();
        DesignBtn = new javax.swing.JButton();
        KeyinBtn = new javax.swing.JButton();
        FeedBtn = new javax.swing.JButton();
        BackBtn1 = new javax.swing.JButton();
        BackBtn = new javax.swing.JButton();
        SaveBtn1 = new javax.swing.JButton();
        ModuleComb = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        AssTypeComb = new javax.swing.JComboBox<>();
        StudentLbl = new javax.swing.JLabel();
        StudentComb = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        FeedbackTA = new java.awt.TextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 140, 0));
        setForeground(java.awt.Color.white);
        setSize(new java.awt.Dimension(500, 200));

        label1.setFont(new java.awt.Font("Arial Black", 0, 30)); // NOI18N
        label1.setPreferredSize(new java.awt.Dimension(50, 20));
        label1.setText("Provide Feedback");

        jPanel5.setBackground(new java.awt.Color(255, 140, 0));

        EditBtn.setLabel("Edit Profile");
        EditBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditBtnActionPerformed(evt);
            }
        });

        DesignBtn.setLabel("Design Assessment Type");
        DesignBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DesignBtnActionPerformed(evt);
            }
        });

        KeyinBtn.setLabel("Key-In Mark");
        KeyinBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KeyinBtnActionPerformed(evt);
            }
        });

        FeedBtn.setLabel("Provide Feedback");
        FeedBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FeedBtnActionPerformed(evt);
            }
        });

        BackBtn1.setText("Homepage");
        BackBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackBtn1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(KeyinBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DesignBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(EditBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(FeedBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
                    .addComponent(BackBtn1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(11, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(115, 115, 115)
                .addComponent(EditBtn)
                .addGap(32, 32, 32)
                .addComponent(DesignBtn)
                .addGap(29, 29, 29)
                .addComponent(KeyinBtn)
                .addGap(31, 31, 31)
                .addComponent(FeedBtn)
                .addGap(30, 30, 30)
                .addComponent(BackBtn1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        EditBtn.getAccessibleContext().setAccessibleName("EditProfilBtn");
        DesignBtn.getAccessibleContext().setAccessibleName("DesignAssTypeBtn");
        KeyinBtn.getAccessibleContext().setAccessibleName("KeyInMarkBtn");
        FeedBtn.getAccessibleContext().setAccessibleName("FeedbackBtn");

        BackBtn.setText("Back");
        BackBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackBtnActionPerformed(evt);
            }
        });

        SaveBtn1.setText("Save");
        SaveBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveBtn1ActionPerformed(evt);
            }
        });

        ModuleComb.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        ModuleComb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModuleCombActionPerformed(evt);
            }
        });

        jLabel3.setText("Feedback:");

        AssTypeComb.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        StudentLbl.setText("Student Name:");

        StudentComb.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        StudentComb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StudentCombActionPerformed(evt);
            }
        });

        jLabel1.setText("Select Module:");

        jLabel2.setText("Assessment Type:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 76, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel2)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(StudentLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(43, 43, 43)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(ModuleComb, 0, 239, Short.MAX_VALUE)
                            .addComponent(AssTypeComb, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(StudentComb, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(FeedbackTA, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(128, 128, 128))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(152, 152, 152)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(SaveBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(29, 29, 29)
                                .addComponent(BackBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(ModuleComb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(StudentComb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(StudentLbl))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AssTypeComb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(FeedbackTA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SaveBtn1)
                            .addComponent(BackBtn))
                        .addGap(14, 14, 14))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jLabel3)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void EditBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditBtnActionPerformed
        new EditProfileAss().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_EditBtnActionPerformed

    private void DesignBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DesignBtnActionPerformed
        new DesignAss().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_DesignBtnActionPerformed

    private void KeyinBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KeyinBtnActionPerformed
        new KeyInMarkAss().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KeyinBtnActionPerformed

    private void FeedBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FeedBtnActionPerformed
        new Feedback().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_FeedBtnActionPerformed

    private void BackBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackBtnActionPerformed
        new Lecturerpage().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackBtnActionPerformed

    private void ModuleCombActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModuleCombActionPerformed
        loadStudentNameCombo();
        loadAssessmentTypeCombo();
    }//GEN-LAST:event_ModuleCombActionPerformed

    private void BackBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackBtn1ActionPerformed
        new Lecturerpage().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackBtn1ActionPerformed

    private void StudentCombActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StudentCombActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_StudentCombActionPerformed

    private void SaveBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveBtn1ActionPerformed
        saveFeedback();
    }//GEN-LAST:event_SaveBtn1ActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> new Feedback().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> AssTypeComb;
    private javax.swing.JButton BackBtn;
    private javax.swing.JButton BackBtn1;
    private javax.swing.JButton DesignBtn;
    private javax.swing.JButton EditBtn;
    private javax.swing.JButton FeedBtn;
    private java.awt.TextArea FeedbackTA;
    private javax.swing.JButton KeyinBtn;
    private javax.swing.JComboBox<String> ModuleComb;
    private javax.swing.JButton SaveBtn1;
    private javax.swing.JComboBox<String> StudentComb;
    private javax.swing.JLabel StudentLbl;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel5;
    private java.awt.Label label1;
    // End of variables declaration//GEN-END:variables
}
