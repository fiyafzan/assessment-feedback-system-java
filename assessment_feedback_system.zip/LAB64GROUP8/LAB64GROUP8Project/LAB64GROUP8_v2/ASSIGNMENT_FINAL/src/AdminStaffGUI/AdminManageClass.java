package AdminStaffGUI;
import MainClass.Assignment;
import Classes.DataIO;
import Classes.Login;
import Classes.Module;
import AdminStaffGUI.AdminAssignLecturer;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
public class AdminManageClass extends javax.swing.JFrame {

    // Create a model for the List so we can add/remove items dynamically
    DefaultListModel<String> listModel = new DefaultListModel<>();
    
    public AdminManageClass() {
        initComponents();
        this.setTitle("Admin Manage Class Page");
        this.setLocationRelativeTo(null);
        lstClassinModule.setModel(listModel); // connect the list GUI to our Model
        loadModulesToDropdown();
        
    }   
    
    // Load Modules into the Combo Box
    private void loadModulesToDropdown() {
        cboModule.removeAllItems(); // Clear Items
        for (Module m : DataIO.allModules){
            cboModule.addItem(m.getModuleName()); // Add module name            
        }      
        
        // Reset selection so the user has to pick one to start
        cboModule.setSelectedIndex(-1);
        listModel.clear();
    }
    
    // Refresh the Class List based on selection
    private void refreshClassList() {
        listModel.clear();
        String selectedName = (String) cboModule.getSelectedItem();
        
        // Find the actual Module Object
        Module m = findModuleByName(selectedName);
        
        if (m != null){
            // Loop through its classes and add to the visual list
            for (String className : m.getClassNames()){
                listModel.addElement(className);
            }
        }
    }
    
    private void createClass() {
        String selectedName = (String) cboModule.getSelectedItem();
        String newClassName = txtAddClass.getText().trim();
        
        // Validation 1: Did they select a module?
        if (selectedName == null){
            JOptionPane.showMessageDialog(this, "Please select a Module first!");
            return;
        }
        
        // Validation 2: Is the box empty?
        if (newClassName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a Class Name (e.g. L1).");
            return;
        }
        
        Module m = findModuleByName(selectedName);
        if (m != null) {
            // Validation 3: Duplicates
            if (m.getClassNames().contains(newClassName)) {
                JOptionPane.showMessageDialog(this, "Class '" + newClassName + "' already exists!");
                return;
            }

            // SUCCESS: Add and Save
            m.addClass(newClassName);
            DataIO.write(); // Save to text file
            
            // Update the screen
            refreshClassList();
            txtAddClass.setText(""); 
            JOptionPane.showMessageDialog(this, "Class created successfully!");
        }
    }
    
    // Helper: Find the object in the ArrayList using just the name
    private Module findModuleByName(String name) {
        for (Module m : DataIO.allModules) {
            if (m.getModuleName().equals(name)) {
                return m;
            }
        }
        return null;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        btnLogout = new javax.swing.JButton();
        btnUserManagement = new javax.swing.JButton();
        btnAssignLecturer = new javax.swing.JButton();
        btnGrading = new javax.swing.JButton();
        btnManageClass = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        cboModule = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        txtAddClass = new javax.swing.JTextField();
        btnAddClass = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        lstClassinModule = new javax.swing.JList<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(70, 130, 180));

        btnLogout.setText("Logout");
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });

        btnUserManagement.setText("User Management");
        btnUserManagement.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUserManagementActionPerformed(evt);
            }
        });

        btnAssignLecturer.setText("Assign Lecturers");
        btnAssignLecturer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAssignLecturerActionPerformed(evt);
            }
        });

        btnGrading.setText("Grading System");
        btnGrading.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGradingActionPerformed(evt);
            }
        });

        btnManageClass.setText("Manage Classes");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnUserManagement, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnLogout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnAssignLecturer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnGrading, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnManageClass, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(btnUserManagement)
                .addGap(45, 45, 45)
                .addComponent(btnAssignLecturer)
                .addGap(45, 45, 45)
                .addComponent(btnGrading)
                .addGap(45, 45, 45)
                .addComponent(btnManageClass)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnLogout)
                .addGap(47, 47, 47))
        );

        jLabel1.setFont(new java.awt.Font("Kristen ITC", 1, 36)); // NOI18N
        jLabel1.setText("Manage Classes Page");

        jPanel1.setBackground(new java.awt.Color(70, 130, 180));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel3.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel3.setText("Select Module");

        cboModule.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboModule.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboModuleActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel5.setText("Add Class to the Module");

        txtAddClass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAddClassActionPerformed(evt);
            }
        });

        btnAddClass.setText("Create Class");
        btnAddClass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddClassActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel4.setText("Current Class in the Module");

        lstClassinModule.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(lstClassinModule);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane1)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cboModule, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                        .addComponent(txtAddClass, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnAddClass)))
                .addGap(14, 127, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cboModule, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtAddClass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAddClass))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(14, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addGap(46, 46, 46))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // --- NAVIGATION BUTTONS ---
    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        // 1. Clear the current session (Security best practice)
    // This ensures that if someone else clicks "Back", they aren't still logged in as you.
    Assignment.loginAdmin = null; 
    
    // 2. Close the current Admin window (dispose removes it from memory)
    this.dispose();
    
    // 3. Show the original Login screen again
    if (Assignment.one != null && Assignment.one.x != null) {        
        Assignment.one.x.setVisible(true); 
        Assignment.one.x.setLocationRelativeTo(null); // Re-center it just in case
    } else {
        // Failsafe: If the original login screen was somehow destroyed, make a new one
        new Login(); 
    }
    }//GEN-LAST:event_btnLogoutActionPerformed

    private void btnUserManagementActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUserManagementActionPerformed
        AdminManageUser manageUserFrame = new AdminManageUser();
        manageUserFrame.setVisible(true);                
        this.dispose();
        manageUserFrame.setLocationRelativeTo(null);
    }//GEN-LAST:event_btnUserManagementActionPerformed

    private void btnAssignLecturerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAssignLecturerActionPerformed
        AdminAssignLecturer assignLecturerFrame = new AdminAssignLecturer();
        assignLecturerFrame.setVisible(true);        
        this.dispose();
        assignLecturerFrame.setLocationRelativeTo(null);
    }//GEN-LAST:event_btnAssignLecturerActionPerformed

    private void btnGradingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGradingActionPerformed
        AdminGrading gradingSystemFrame = new AdminGrading();
        gradingSystemFrame.setVisible(true);        
        this.dispose();
        gradingSystemFrame.setLocationRelativeTo(null);
    }//GEN-LAST:event_btnGradingActionPerformed

    private void txtAddClassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAddClassActionPerformed
        createClass();
    }//GEN-LAST:event_txtAddClassActionPerformed

    private void btnAddClassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddClassActionPerformed
        createClass();                      
    }//GEN-LAST:event_btnAddClassActionPerformed

    private void cboModuleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboModuleActionPerformed
        refreshClassList();
    }//GEN-LAST:event_cboModuleActionPerformed

    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminManageClass.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminManageClass.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminManageClass.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminManageClass.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminManageClass().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddClass;
    private javax.swing.JButton btnAssignLecturer;
    private javax.swing.JButton btnGrading;
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnManageClass;
    private javax.swing.JButton btnUserManagement;
    private javax.swing.JComboBox<String> cboModule;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<String> lstClassinModule;
    private javax.swing.JTextField txtAddClass;
    // End of variables declaration//GEN-END:variables
}
