package AdminStaffGUI;

import Classes.AcademicLeader;
import Classes.AdminStaff;
import MainClass.Assignment;
import Classes.DataIO;
import Classes.Lecturer;
import Classes.Login;
import Classes.Student;
import AdminStaffGUI.AdminAssignLecturer;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class AdminManageUser extends javax.swing.JFrame {

    DefaultTableModel model;
    
    public AdminManageUser() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setTitle("Admin Manage User Page");
        
        // --- ADD THIS LINE TO FIX THE COMBO BOX ---
    cboRole.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Admin Staff", "Academic Leader", "Lecturer", "Student" }));
        
        // Setup Table Columns
        String[] columns = {"Username", "Password", "UserID", "Name", "Email", "Phone", "Age", "Role-Specific"};
        model = new DefaultTableModel(columns, 0);
        tblUsers.setModel(model);
        
        // Default: Load Admin Staff
        cboRole.setSelectedItem("Admin Staff");
        loadData("Admin Staff");        
    }
    
    // --- 1. READ (Load Data into Table) ---
    private void loadData(String role){
        model.setRowCount(0); // Clear table
        
        // Update the Label for the extra field based on role
        updateRoleLabel(role);
        
        if (role.equals("Admin Staff")){
            for (AdminStaff AS : DataIO.allAdminStaff){
                model.addRow(new Object[]{AS.getUsername(), AS.getPassword(), AS.getUserID(), AS.getFullname(), AS.getEmail(), AS.getPhone(), AS.getAge(), "-"});
            }
        } else if (role.equals("Academic Leader")) {
            for (AcademicLeader AL : DataIO.allAcademicLeader) {
                model.addRow(new Object[]{AL.getUsername(), AL.getPassword(), AL.getUserID(), AL.getFullname(), AL.getEmail(), AL.getPhone(), AL.getAge(), AL.getLecturers()});
            }
        } else if (role.equals("Lecturer")) {
            for (Lecturer L : DataIO.allLecturer) {
                model.addRow(new Object[]{L.getUsername(), L.getPassword(), L.getUserID(), L.getFullname(), L.getEmail(), L.getPhone(), L.getAge(), L.getModule()});
            }
        } else if (role.equals("Student")) {
            for (Student S : DataIO.allStudent) {
                model.addRow(new Object[]{S.getUsername(), S.getPassword(), S.getUserID(), S.getFullname(), S.getEmail(), S.getPhone(), S.getAge(), S.getModule()});
            }
    }
    }
    
    private void updateRoleLabel(String role){
        if (role.equals("Admin Staff")){
            lblRoleSpecific.setText("N/A:");
            txtRoleSpecific.setEnabled(false); // Admin do not have extra fields
        }  else if (role.equals("Student")) {
            lblRoleSpecific.setText("Intake/Module:");
            txtRoleSpecific.setEnabled(true);
        } else if (role.equals("Lecturer")) {
            lblRoleSpecific.setText("Module Taught:");
            txtRoleSpecific.setEnabled(true);
        } else {
            lblRoleSpecific.setText("Assigned Lecs:");
            txtRoleSpecific.setEnabled(true);
        }    
    }
    
    // --- 2. CREATE (Add New User) ---
    private void createUser() {
        String role = cboRole.getSelectedItem().toString();
        
        // Gather data from text fields
        String user = txtUsername.getText();
        String pass = txtPassword.getText();
        String id = txtUserID.getText();
        String name = txtName.getText();
        String email = txtEmail.getText();
        String phone = txtPhone.getText();
        String age = txtAge.getText();
        String extra = txtRoleSpecific.getText(); // The dynamic field
        
        // Basic Validation
        if (user.isEmpty() || pass.isEmpty() || id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields!");
            return;
        }
        
        // Add to the correct ArrayList in DataIO
        if (role.equals("Admin Staff")) {
            DataIO.allAdminStaff.add(new AdminStaff(user, pass, id , name, email, phone, age));            
        } else if (role.equals("Academic Leader")) {
            DataIO.allAcademicLeader.add(new AcademicLeader(user, pass, id, name, email, phone, age, extra));
        } else if (role.equals("Lecturer")) {
            // Note: Lecturer has "assignedTo" (Leader) and "Module". 
            // We set assignedTo to "None" initially. It gets set in the "Assign Lecturer" page.
            DataIO.allLecturer.add(new Lecturer(user, pass, id, name, email, phone, age, "None", extra));
        } else if (role.equals("Student")) {
            DataIO.allStudent.add(new Student(user, pass, id, name, email, phone, age, extra));
        }
        
        DataIO.write(); // save immediately
        loadData(role); // Refresh Table
        clearFields();
        JOptionPane.showMessageDialog(this, "User Created Successfully!");
    }
    
    // --- 3. UPDATE (Edit Existing User) ---
    private void updateUser() {
        String role = cboRole.getSelectedItem().toString();
        int selectedRow = tblUsers.getSelectedRow();
        
        if (selectedRow == -1){
            JOptionPane.showMessageDialog(this, "Please select a row to update.");
            return;
        }
        
        // We use the ID Column to find the unique user
        String originalID = model.getValueAt(selectedRow, 2).toString();
        
        // Loop through list, find the ID, update the data
        if (role.equals("Admin Staff")){
            for (AdminStaff AS : DataIO.allAdminStaff) {
                if (AS.getUserID().equals(originalID)) {
                    AS.setUsername(txtUsername.getText());
                    AS.setPassword(txtPassword.getText());
                    AS.setFullname(txtName.getText());
                    AS.setEmail(txtEmail.getText());
                    AS.setPhone(txtPhone.getText());
                    AS.setAge(txtAge.getText());
                    break;
                }
            }
        } else if (role.equals("Student")) {
            for (Student S : DataIO.allStudent) {
                if (S.getUserID().equals(originalID)) {
                    S.setUsername(txtUsername.getText());
                    S.setPassword(txtPassword.getText());
                    S.setFullname(txtName.getText());
                    S.setEmail(txtEmail.getText());
                    S.setPhone(txtPhone.getText());
                    S.setAge(txtAge.getText());
                    S.setModule(txtRoleSpecific.getText());
                    break;
                }
            }
        } else if (role.equals("Lecturer")) {
            for (Lecturer L : DataIO.allLecturer) {
                if (L.getUserID().equals(originalID)) {
                    L.setUsername(txtUsername.getText());
                    L.setPassword(txtPassword.getText());
                    L.setFullname(txtName.getText());
                    L.setEmail(txtEmail.getText());
                    L.setPhone(txtPhone.getText());
                    L.setAge(txtAge.getText());
                    L.setModule(txtRoleSpecific.getText());
                    break;
                }
            }
        } else if (role.equals("Academic Leader")) {
            for (AcademicLeader AL : DataIO.allAcademicLeader) {
                if (AL.getUserID().equals(originalID)) {
                    AL.setUsername(txtUsername.getText());
                    AL.setPassword(txtPassword.getText());
                    AL.setFullname(txtName.getText());
                    AL.setEmail(txtEmail.getText());
                    AL.setPhone(txtPhone.getText());
                    AL.setAge(txtAge.getText());
                    AL.setLecturers(txtRoleSpecific.getText());
                    break;
                }
            }
        }
        
        DataIO.write();
        loadData(role);
        clearFields();
        JOptionPane.showMessageDialog(this, "User Updated Successfully!");
    }
    
    // --- 4. DELETE (Remove User) ---
    private void deleteUser(){
        String role = cboRole.getSelectedItem().toString();
        int selectedRow = tblUsers.getSelectedRow();
        
        if (selectedRow == -1){
            JOptionPane.showMessageDialog(this, "Please select a row to delete.");
            return;
        }
        
        String targetID = model.getValueAt(selectedRow, 2).toString();
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete ID: " + targetID + "?");
        if (confirm != JOptionPane.YES_OPTION) return;
        
        // removeIf is a quick way to delete items from an ArrayList
        if (role.equals("Admin Staff")) {
            DataIO.allAdminStaff.removeIf(AS -> AS.getUserID().equals(targetID));
        } else if (role.equals("Academic Leader")) {
            DataIO.allAcademicLeader.removeIf(AL -> AL.getUserID().equals(targetID));
        } else if (role.equals("Lecturer")) {
            DataIO.allLecturer.removeIf(L -> L.getUserID().equals(targetID));
        } else if (role.equals("Student")) {
            DataIO.allStudent.removeIf(S -> S.getUserID().equals(targetID));
        }
        
        DataIO.write();
        loadData(role);
        clearFields();
        JOptionPane.showMessageDialog(this, "User Deleted!");
    }
    
    // --- HELPER: Click Table Row -> Fill Text Fields ---
    private void fillFieldsFromTable(){
        int row = tblUsers.getSelectedRow();
        if (row != -1){
            txtUsername.setText(model.getValueAt(row, 0).toString());
            txtPassword.setText(model.getValueAt(row, 1).toString());
            txtUserID.setText(model.getValueAt(row, 2).toString());
            txtName.setText(model.getValueAt(row, 3).toString());
            txtEmail.setText(model.getValueAt(row, 4).toString());
            txtPhone.setText(model.getValueAt(row, 5).toString());
            txtAge.setText(model.getValueAt(row, 6).toString());
            txtRoleSpecific.setText(model.getValueAt(row, 7).toString());
        }
    }
    
    private void clearFields(){
        txtUsername.setText("");
        txtPassword.setText("");
        txtUserID.setText("");
        txtName.setText("");
        txtEmail.setText("");
        txtPhone.setText("");
        txtAge.setText("");
        txtRoleSpecific.setText("");
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btnLogout = new javax.swing.JButton();
        btnUserManagement = new javax.swing.JButton();
        btnAssignLecturer = new javax.swing.JButton();
        btnGrading = new javax.swing.JButton();
        btnManageClass = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        btnCreate = new javax.swing.JButton();
        btnRead = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        cboRole = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblUsers = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtUsername = new javax.swing.JTextField();
        txtUserID = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtAge = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        lblRoleSpecific = new javax.swing.JLabel();
        txtPassword = new javax.swing.JTextField();
        txtPhone = new javax.swing.JTextField();
        txtName = new javax.swing.JTextField();
        txtRoleSpecific = new javax.swing.JTextField();
        btnClear = new javax.swing.JButton();

        jLabel3.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel3.setText("Set Grade");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(70, 130, 180));

        btnLogout.setText("Logout");
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });

        btnUserManagement.setText("User Management");

        btnAssignLecturer.setText("Assign Lecturers");
        btnAssignLecturer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAssignLecturerActionPerformed(evt);
            }
        });

        btnGrading.setText("Grading System");
        btnGrading.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGradingActionPerformed(evt);
            }
        });

        btnManageClass.setText("Manage Classes");
        btnManageClass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnManageClassActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnUserManagement, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnAssignLecturer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnGrading, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnManageClass, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLogout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(btnUserManagement)
                .addGap(45, 45, 45)
                .addComponent(btnAssignLecturer)
                .addGap(45, 45, 45)
                .addComponent(btnGrading)
                .addGap(45, 45, 45)
                .addComponent(btnManageClass)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 45, Short.MAX_VALUE)
                .addComponent(btnLogout)
                .addGap(44, 44, 44))
        );

        jLabel1.setFont(new java.awt.Font("Kristen ITC", 1, 36)); // NOI18N
        jLabel1.setText("User Management Page");

        jPanel1.setBackground(new java.awt.Color(70, 130, 180));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        btnCreate.setText("Create");
        btnCreate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCreateActionPerformed(evt);
            }
        });

        btnRead.setText("Read");
        btnRead.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReadActionPerformed(evt);
            }
        });

        btnUpdate.setText("Update");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel4.setText("Select Role to See:");

        cboRole.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Admin Staff", "Academic Leader", "Lecturer", "Student" }));
        cboRole.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboRoleActionPerformed(evt);
            }
        });

        tblUsers.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblUsers.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblUsersMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblUsers);

        jLabel2.setText("Username:");

        jLabel5.setText("UserID:");

        jLabel6.setText("Email:");

        jLabel7.setText("Age:");

        txtUserID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUserIDActionPerformed(evt);
            }
        });

        jLabel8.setText("Password:");

        jLabel9.setText("Full Name:");

        jLabel10.setText("Phone:");

        lblRoleSpecific.setText("Role Specific:");

        txtPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPasswordActionPerformed(evt);
            }
        });

        txtPhone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPhoneActionPerformed(evt);
            }
        });

        txtName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNameActionPerformed(evt);
            }
        });

        txtRoleSpecific.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRoleSpecificActionPerformed(evt);
            }
        });

        btnClear.setText("Clear");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnCreate)
                        .addGap(26, 26, 26)
                        .addComponent(btnRead)
                        .addGap(28, 28, 28)
                        .addComponent(btnUpdate)
                        .addGap(18, 18, 18)
                        .addComponent(btnDelete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnClear))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cboRole, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(64, 64, 64)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addGap(28, 28, 28)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtAge, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtEmail, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtUserID, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtUsername, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(29, 29, 29)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel10)
                                    .addComponent(lblRoleSpecific)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel8))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtPhone, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtRoleSpecific, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cboRole, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(21, 21, 21)
                        .addComponent(jLabel5))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8)
                            .addComponent(txtPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtUserID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9)
                            .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)
                            .addComponent(jLabel10)
                            .addComponent(txtPhone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtAge, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7)
                            .addComponent(lblRoleSpecific)
                            .addComponent(txtRoleSpecific, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCreate)
                    .addComponent(btnRead)
                    .addComponent(btnUpdate)
                    .addComponent(btnDelete)
                    .addComponent(btnClear))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jLabel1)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // --- NAVIGATION BUTTONS ---
    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
    // 1. Clear the current session (Security best practice)
    // This ensures that if someone else clicks "Back", they aren't still logged in as you.
    Assignment.loginAdmin = null; 
    
    // 2. Close the current Admin window (dispose removes it from memory)
    this.dispose();
    
    // 3. Show the original Login screen again
    if (Assignment.one != null && Assignment.one.x != null) {        
        Assignment.one.x.setVisible(true); 
        Assignment.one.x.setLocationRelativeTo(null); // Re-center it just in case
    } else {
        // Failsafe: If the original login screen was somehow destroyed, make a new one
        new Login(); 
    }
    }//GEN-LAST:event_btnLogoutActionPerformed

    private void btnAssignLecturerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAssignLecturerActionPerformed
        AdminAssignLecturer assignLecturerFrame = new AdminAssignLecturer();
        assignLecturerFrame.setVisible(true);        
        this.dispose();
        assignLecturerFrame.setLocationRelativeTo(null);
    }//GEN-LAST:event_btnAssignLecturerActionPerformed

    private void btnGradingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGradingActionPerformed
        AdminGrading gradingSystemFrame = new AdminGrading();
        gradingSystemFrame.setVisible(true);        
        this.dispose();
        gradingSystemFrame.setLocationRelativeTo(null);
    }//GEN-LAST:event_btnGradingActionPerformed

    private void btnManageClassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnManageClassActionPerformed
        AdminManageClass manageClassFrame = new AdminManageClass();
        manageClassFrame.setVisible(true);        
        this.dispose();
        manageClassFrame.setLocationRelativeTo(null);
    }//GEN-LAST:event_btnManageClassActionPerformed

    private void btnCreateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCreateActionPerformed
        createUser();
    }//GEN-LAST:event_btnCreateActionPerformed

    private void txtUserIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUserIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUserIDActionPerformed

    private void txtPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPasswordActionPerformed

    private void txtPhoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPhoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPhoneActionPerformed

    private void txtNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNameActionPerformed

    private void txtRoleSpecificActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRoleSpecificActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRoleSpecificActionPerformed

    private void cboRoleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboRoleActionPerformed
        loadData(cboRole.getSelectedItem().toString());
    }//GEN-LAST:event_cboRoleActionPerformed

    private void tblUsersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblUsersMouseClicked
        fillFieldsFromTable();
    }//GEN-LAST:event_tblUsersMouseClicked

    private void btnReadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReadActionPerformed
        // Get the currently selected role (e.g., "Student")
        String currentRole = cboRole.getSelectedItem().toString();
        
        // Force the table to reload the data for that role
        loadData(currentRole);
        
        // Clear the text fields too
        clearFields();
    }//GEN-LAST:event_btnReadActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        updateUser();
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        deleteUser();
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        clearFields();
    }//GEN-LAST:event_btnClearActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminManageUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminManageUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminManageUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminManageUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminManageUser().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAssignLecturer;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnCreate;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnGrading;
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnManageClass;
    private javax.swing.JButton btnRead;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JButton btnUserManagement;
    private javax.swing.JComboBox<String> cboRole;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblRoleSpecific;
    private javax.swing.JTable tblUsers;
    private javax.swing.JTextField txtAge;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtPassword;
    private javax.swing.JTextField txtPhone;
    private javax.swing.JTextField txtRoleSpecific;
    private javax.swing.JTextField txtUserID;
    private javax.swing.JTextField txtUsername;
    // End of variables declaration//GEN-END:variables
}
