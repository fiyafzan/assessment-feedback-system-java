package Classes;

/**
 * StudentFeedback class - Represents feedback from students to lecturers
 * This is separate from FeedbackclassAss which is used for lecturer's assessment feedback
 * Demonstrates: Encapsulation, Clear class responsibility
 */
public class StudentFeedback {
    
    // Encapsulation - private fields
    private String feedbackId;
    private String studentId;
    private String studentName;
    private String lecturerName;
    private String module;
    private int rating;  // 1-5 stars
    private String comments;
    private String timestamp;
    
    // Constructor
    public StudentFeedback(String feedbackId, String studentId, String studentName, 
                          String lecturerName, String module, int rating, 
                          String comments, String timestamp) {
        this.feedbackId = feedbackId;
        this.studentId = studentId;
        this.studentName = studentName;
        this.lecturerName = lecturerName;
        this.module = module;
        this.rating = rating;
        this.comments = comments;
        this.timestamp = timestamp;
    }
    
    // Getters
    public String getFeedbackId() {
        return feedbackId;
    }
    
    public String getStudentId() {
        return studentId;
    }
    
    public String getStudentName() {
        return studentName;
    }
    
    public String getLecturerName() {
        return lecturerName;
    }
    
    public String getModule() {
        return module;
    }
    
    public int getRating() {
        return rating;
    }
    
    public String getComments() {
        return comments;
    }
    
    public String getTimestamp() {
        return timestamp;
    }
    
    // Setters
    public void setFeedbackId(String feedbackId) {
        this.feedbackId = feedbackId;
    }
    
    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }
    
    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }
    
    public void setLecturerName(String lecturerName) {
        this.lecturerName = lecturerName;
    }
    
    public void setModule(String module) {
        this.module = module;
    }
    
    public void setRating(int rating) {
        this.rating = rating;
    }
    
    public void setComments(String comments) {
        this.comments = comments;
    }
    
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
    
    // Override toString for easy display
    @Override
    public String toString() {
        return "StudentFeedback{" +
                "feedbackId='" + feedbackId + '\'' +
                ", studentName='" + studentName + '\'' +
                ", lecturerName='" + lecturerName + '\'' +
                ", module='" + module + '\'' +
                ", rating=" + rating +
                ", timestamp='" + timestamp + '\'' +
                '}';
    }
}
