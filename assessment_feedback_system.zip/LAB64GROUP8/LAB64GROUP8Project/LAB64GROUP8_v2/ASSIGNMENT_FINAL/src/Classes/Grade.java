package Classes;
public class Grade {
    private String gradeName; // e.g., "A+"
    private double minMark; // e.g., 80
    private double maxMark; // e.g., 100
    
    //constructor
    public Grade(String gradeName, double minMark, double maxMark) {
        this.gradeName = gradeName;
        this.minMark = minMark;
        this.maxMark = maxMark;
    }          
    
    //getter
    public String getGradeName() {
        return gradeName;
    }

    public double getMinMark() {
        return minMark;
    }

    public double getMaxMark() {
        return maxMark;
    }
    
    //setter
    public void setGradeName(String gradeName) {
        this.gradeName = gradeName;
    }

    public void setMinMark(double minMark) {
        this.minMark = minMark;
    }

    public void setMaxMark(double maxMark) {
        this.maxMark = maxMark;
    }
    
    // Helper to return format like "80-100" for the text file
    public String getRangeString() {
        // (int) removes the decimal point if it is a whole number, making it look cleaner
        if (minMark % 1 == 0 && maxMark % 1 == 0){
            return (int)minMark + "-" + (int)maxMark;
        }
        return minMark + "-" + maxMark;
    }
}
