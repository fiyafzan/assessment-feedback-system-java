package Classes;

// Inheritance applied
public class Student extends User{
    private String module; // Unique to Student

    public Student(String username, String password, String userID, String fullname, String email, String phone, String age, String module) {
        super(username, password, userID, fullname, email, phone, age);
        this.module = module;
    }

    public String getModule() { return module; }
    public void setModule(String module) { this.module = module; }

    // Polymorphism applied
    @Override
    public String getRole() {
        return "Student";
    }
}
