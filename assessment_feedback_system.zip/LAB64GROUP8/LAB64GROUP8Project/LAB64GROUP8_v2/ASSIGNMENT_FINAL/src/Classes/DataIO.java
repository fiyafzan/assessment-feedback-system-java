package Classes;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class DataIO {
    // Storing Profile Infos
    public static ArrayList<AdminStaff> allAdminStaff = new ArrayList<AdminStaff>();
    public static ArrayList<AcademicLeader> allAcademicLeader = new ArrayList<AcademicLeader>();    
    public static ArrayList<Lecturer> allLecturer = new ArrayList<Lecturer>();
    public static ArrayList<Student> allStudent = new ArrayList<Student>();  
    
    // Admin Staff related Arrays  
    
    public static ArrayList<Grade> allGrades = new ArrayList<Grade>();    
    public static ArrayList<Module> allModules = new ArrayList<Module>();
    
    // Academic Leader related Arrays
    
    // Lecturer related Arrays
    // Lecturer related Arrays (merged from DataIO_Lecturer)
    public static ArrayList<AssessmentTypeAss> allAssessmentType = new ArrayList<AssessmentTypeAss>();
    public static ArrayList<AssessmentAss> allAssessment = new ArrayList<AssessmentAss>();
    public static ArrayList<FeedbackclassAss> allFeedback = new ArrayList<FeedbackclassAss>();
    
    
    // Student related Arrays
    public static ArrayList<StudentFeedback> allStudentFeedback = new ArrayList<StudentFeedback>();
    
    
    // -- CHECK NAME METHODS --
    // method to check AdminStaff name 
    public static AdminStaff checkName(String username){
        // assume that the username is not found first (for safety)
        AdminStaff found = null;        
        for(AdminStaff x : allAdminStaff){
            if(username.equals(x.getUsername())){
                found = x;
                break;                
            }
        }
        return found;
    }
    
    public static AcademicLeader checkName2(String username){
        AcademicLeader found = null;
        for(AcademicLeader x : allAcademicLeader){
            if(username.equals(x.getUsername())){
                found = x;
                break;
            }
        }
        return found;
    }
    
    public static Lecturer checkName3(String username){
        Lecturer found = null;
        for(Lecturer x : allLecturer){
            if(username.equals(x.getUsername())){
                found = x;
                break;
            }
        }
        return found;
    }
    
    public static Student checkName4(String username){
        Student found = null;
        for(Student x : allStudent){
            if(username.equals(x.getUsername())){
                found = x;
                break;
            }
        }
        return found;
    }
      
    // -- FILE OPERATIONS --
    public static void write(){
        try{
            PrintWriter AS = new PrintWriter("adminstaff.txt");
            for(AdminStaff x : allAdminStaff){
                AS.println(x.getUsername());
                AS.println(x.getPassword());
                AS.println(x.getUserID());
                AS.println(x.getFullname());
                AS.println(x.getEmail());
                AS.println(x.getPhone());
                AS.println(x.getAge());
                AS.println();  // empty space for differentiating            
            }            
            AS.close(); // avoid overlapping
            
            PrintWriter AL = new PrintWriter("academicleader.txt");
            for(AcademicLeader x : allAcademicLeader){
                AL.println(x.getUsername());
                AL.println(x.getPassword());
                AL.println(x.getUserID());
                AL.println(x.getFullname());
                AL.println(x.getEmail());
                AL.println(x.getPhone());
                AL.println(x.getAge());
                AL.println(x.getLecturers());
                AL.println();
            }
            AL.close();
            
            PrintWriter L = new PrintWriter("lecturer.txt");
            for(Lecturer x : allLecturer){
                L.println(x.getUsername());
                L.println(x.getPassword());
                L.println(x.getUserID());
                L.println(x.getFullname());
                L.println(x.getEmail());
                L.println(x.getPhone());
                L.println(x.getAge());
                L.println(x.getAssignedTo());
                L.println(x.getModule());
                L.println();
            }
            L.close();
            
            PrintWriter S = new PrintWriter("student.txt");
            for(Student x : allStudent){
                S.println(x.getUsername());
                S.println(x.getPassword());
                S.println(x.getUserID());
                S.println(x.getFullname());
                S.println(x.getEmail());
                S.println(x.getPhone());
                S.println(x.getAge());
                S.println(x.getModule());
                S.println();
            }
            S.close();
            
            // Admin Staff Part
            PrintWriter G = new PrintWriter("grading.txt");
            for (Grade g : allGrades) {
                G.println(g.getGradeName());
                G.println(g.getRangeString()); // e.g. "80-100"
            }
            G.close();
            
            PrintWriter M = new PrintWriter("modules.txt");
            for(Module m : allModules){
                M.println(m.getModuleName());
                M.println(m.getClassesAsString()); // saves as "L1,T1,T2" or "None"
                M.println();
            }
            M.close();
            
            // Lecturer-specific data
            PrintWriter AT = new PrintWriter("AssessmentType.txt");
            for(AssessmentTypeAss x : allAssessmentType){
                AT.println(x.getModule());
                AT.println(x.getAssessmentType());
                AT.println(x.getWeightage());
                AT.println(x.getMaxMark());
                AT.println();
            }  
            AT.close();

            PrintWriter A = new PrintWriter("Assessment.txt");
            for(AssessmentAss x : allAssessment){
                A.println(x.getModule());
                A.println(x.getAssessmentType());
                A.println(x.getStudentName());
                A.println(x.getMark());
                A.println();
            }
            A.close();

            PrintWriter F = new PrintWriter("Feedback.txt");
            for(FeedbackclassAss x : allFeedback){
                F.println(x.getModule());
                F.println(x.getStudentName());
                F.println(x.getAssessmentType());
                F.println(x.getFeedback());
                F.println();
            }
            F.close();
            
            // Student Feedback (separate from lecturer feedback)
            PrintWriter SF = new PrintWriter("StudentFeedback.txt");
            for(StudentFeedback x : allStudentFeedback){
                SF.println(x.getFeedbackId());
                SF.println(x.getStudentId());
                SF.println(x.getStudentName());
                SF.println(x.getLecturerName());
                SF.println(x.getModule());
                SF.println(x.getRating());
                SF.println(x.getComments());
                SF.println(x.getTimestamp());
                SF.println();
            }
            SF.close();
            
        }catch(Exception e){
            System.out.println("Error in write .....");
            e.printStackTrace(); // to show which is the error in red line
        }
    }
    
    public static void read(){
        try{            
            Scanner s = new Scanner(new File("adminstaff.txt"));
            while(s.hasNextLine()){
                // hasNext means that the scanner has not finished reading the file so it goes to next line
                String username = s.nextLine().trim();
                String password = s.nextLine().trim();
                String userID = s.nextLine().trim();
                String fullname = s.nextLine().trim();
                String email = s.nextLine().trim();
                String phone = s.nextLine().trim();
                String age = s.nextLine().trim();
                if(s.hasNextLine()) s.nextLine();  // Skip empty line if it exists
                allAdminStaff.add(new AdminStaff(username, password, userID, fullname, email, phone, age));
            }
            s.close();
            
            Scanner s2 = new Scanner(new File("academicleader.txt"));
            while(s2.hasNextLine()){
                String username = s2.nextLine().trim();
                String password = s2.nextLine().trim();
                String userID = s2.nextLine().trim();
                String fullname = s2.nextLine().trim();
                String email = s2.nextLine().trim();
                String phone = s2.nextLine().trim();
                String age = s2.nextLine().trim();
                String lecturers = s2.nextLine().trim();
                if(s2.hasNextLine()) s2.nextLine();
                allAcademicLeader.add(new AcademicLeader(username, password, userID, fullname, email, phone, age, lecturers));
            }
            s2.close();
            
            Scanner s3 = new Scanner(new File("lecturer.txt"));
            while(s3.hasNextLine()){
                String username = s3.nextLine().trim();
                String password = s3.nextLine().trim();
                String userID = s3.nextLine().trim();
                String fullname = s3.nextLine().trim();
                String email = s3.nextLine().trim();
                String phone = s3.nextLine().trim();
                String age = s3.nextLine().trim();
                String assignedTo = s3.nextLine().trim();
                String module = s3.nextLine().trim();
                if(s3.hasNextLine()) s3.nextLine();
                allLecturer.add(new Lecturer(username, password, userID, fullname, email, phone, age, assignedTo, module));
            }
            s3.close();
            
            Scanner s4 = new Scanner(new File("student.txt"));
            while(s4.hasNextLine()){
                String username = s4.nextLine().trim();
                String password = s4.nextLine().trim();
                String userID = s4.nextLine().trim();
                String fullname = s4.nextLine().trim();
                String email = s4.nextLine().trim();
                String phone = s4.nextLine().trim();
                String age = s4.nextLine().trim();
                String module = s4.nextLine().trim();
                if(s4.hasNextLine()) s4.nextLine();
                allStudent.add(new Student(username, password, userID, fullname, email, phone, age, module));
            }
            s4.close();    
            
            // Admin Staff Part
            File gradingFile = new File("grading.txt");
            if(gradingFile.exists()) {
                Scanner s6 = new Scanner(gradingFile);
                while(s6.hasNextLine()){
                    String name = s6.nextLine().trim();
                    if(s6.hasNextLine()){
                        String range = s6.nextLine().trim();
                        // Parse "80-100" into 80 and 100
                        try {
                            String[] parts = range.split("-");
                            double min = Double.parseDouble(parts[0]);
                            double max = Double.parseDouble(parts[1]);
                            allGrades.add(new Grade(name, min, max));
                        } catch (Exception e) {
                            System.out.println("Skipping invalid grade line");
                        }
                    }
                }
                s6.close();
            } else {
                setDefaultGrading();
            }
            
            if(allGrades.isEmpty()){
                setDefaultGrading();
            }
            
            File moduleFile = new File("modules.txt");
            if(moduleFile.exists()){
                Scanner s7 = new Scanner(moduleFile);
                while(s7.hasNextLine()){
                    String name = s7.nextLine().trim();
                    String classesLine = s7.nextLine().trim();
                    if(s7.hasNextLine()) s7.nextLine();
                    
                    Module m = new Module(name);
                    if (!classesLine.equals("None") && !classesLine.isEmpty()){
                        String[] classes = classesLine.split(",");
                        for (String c : classes){
                            m.addClass(c.trim());
                        }
                    }
                    allModules.add(m);
                }
                s7.close();
            } else {
                // Default modules if file doesn't exist
                Module m1 = new Module("Object Oriented Java");
                Module m2 = new Module("Capture The Flag");
                allModules.add(m1);
                allModules.add(m2);
            }

            System.out.println("Data loaded successfully.");
            
            // Lecturer-specific data reading 
            File assessmentTypeFile = new File("AssessmentType.txt");
            if (assessmentTypeFile.exists()) {
                Scanner sAT = new Scanner(assessmentTypeFile);
                while (sAT.hasNextLine()) {
                    String module = sAT.nextLine().trim();
                    String assessmentType = sAT.nextLine().trim();
                    int weightage = Integer.parseInt(sAT.nextLine().trim());
                    int maxMark = Integer.parseInt(sAT.nextLine().trim());
                    if (sAT.hasNextLine()) sAT.nextLine();
                    allAssessmentType.add(new AssessmentTypeAss(module, assessmentType, weightage, maxMark));
                }
                sAT.close();
            }

            // 7. Assessments
            File assessmentFile = new File("Assessment.txt");
            if (assessmentFile.exists()) {
                Scanner sA = new Scanner(assessmentFile);
                while (sA.hasNextLine()) {
                    String module = sA.nextLine().trim();
                    String assessmentType = sA.nextLine().trim();
                    String studentName = sA.nextLine().trim();
                    int mark = Integer.parseInt(sA.nextLine().trim());
                    if (sA.hasNextLine()) sA.nextLine();
                    allAssessment.add(new AssessmentAss(module, assessmentType, studentName, mark));
                }
                sA.close();
            }

            // 8. Feedback
            File feedbackFile = new File("Feedback.txt");
            if (feedbackFile.exists()) {
                Scanner sF = new Scanner(feedbackFile);
                while (sF.hasNextLine()) {
                    String module = sF.nextLine().trim();
                    String studentName = sF.nextLine().trim();
                    String assessmentType = sF.nextLine().trim();
                    String feedback = sF.nextLine().trim();
                    if (sF.hasNextLine()) sF.nextLine();
                    allFeedback.add(new FeedbackclassAss(module, studentName, assessmentType, feedback));
                }
                sF.close();
            }
            
            // 9. Student Feedback (to lecturers)
            File studentFeedbackFile = new File("StudentFeedback.txt");
            if (studentFeedbackFile.exists()) {
                Scanner sSF = new Scanner(studentFeedbackFile);
                while (sSF.hasNextLine()) {
                    String feedbackId = sSF.nextLine().trim();
                    String studentId = sSF.nextLine().trim();
                    String studentName = sSF.nextLine().trim();
                    String lecturerName = sSF.nextLine().trim();
                    String module = sSF.nextLine().trim();
                    int rating = Integer.parseInt(sSF.nextLine().trim());
                    String comments = sSF.nextLine().trim();
                    String timestamp = sSF.nextLine().trim();
                    if (sSF.hasNextLine()) sSF.nextLine();
                    allStudentFeedback.add(new StudentFeedback(feedbackId, studentId, studentName, 
                                                               lecturerName, module, rating, 
                                                               comments, timestamp));
                }
                sSF.close();
            }

            System.out.println("All data loaded successfully.");

        } catch (Exception e) {
            System.out.println("Error in read process: " + e.getMessage());
            e.printStackTrace();
        }
    }
        
        // Admin Staff additional coding for DataIO
        // Setting a default grade
        private static void setDefaultGrading() {
        allGrades.add(new Grade("A+", 80, 100));
        allGrades.add(new Grade("A", 75, 79));
        allGrades.add(new Grade("B+", 70, 74));
        allGrades.add(new Grade("B", 65, 69));
        allGrades.add(new Grade("C+", 60, 64));
        allGrades.add(new Grade("C", 55, 59));
        allGrades.add(new Grade("C-", 50, 54));
        allGrades.add(new Grade("D", 40, 49));
        allGrades.add(new Grade("F+", 30, 39));
        allGrades.add(new Grade("F", 20, 29));
        allGrades.add(new Grade("F-", 0, 19));
    }
        
        // New logic using Grade objects (for grading lecturer's marking)
        public static String calculateGrade(double score){
            for (Grade g : allGrades){
                if (score >= g.getMinMark() && score <= g.getMaxMark()){
                    return g.getGradeName();
                }
            }
            return "Unassigned";
        }
        
        // Helper to find a specific Grade object by name (e.g., find "A+")
        public static Grade getGradeObject(String name) {
            for(Grade g : allGrades){
                if(g.getGradeName().equalsIgnoreCase(name)){
                    return g;
                }
            }
            return null;
        }
}        
