package Classes;

import MainClass.Assignment;
import AcademicLeaderGUI.AcademicLeaderDashboard;
import LecturerGUI.Lecturerpage;
import StudentGUI.StudentPage;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login implements ActionListener{
    public void actionPerformed(ActionEvent e){
        try{
            if(e.getSource() == exit){            
                    System.exit(0); // shutdown immediately                
            } else if(e.getSource() == adminStaff){
                String input = JOptionPane.showInputDialog("Enter username:");
                if(DataIO.checkName(input) == null){
                    throw new Exception();
                }                                               
                String password = JOptionPane.showInputDialog("Enter password:");
                if(!DataIO.checkName(input).getPassword().equals(password)){
                    throw new Exception();
                }                 
                System.out.println("Login successful!");
                Assignment.loginAdmin = DataIO.checkName(input);
                x.setVisible(false);
                Assignment.second.setVisible(true);
                Assignment.second.setLocationRelativeTo(null);
                
            } else if(e.getSource() == academicLeader){                
                String input = JOptionPane.showInputDialog("Enter username:");
                if(DataIO.checkName2(input) == null){
                    throw new Exception();
                }                                               
                String password = JOptionPane.showInputDialog("Enter password:");
                if(!DataIO.checkName2(input).getPassword().equals(password)){
                    throw new Exception();
                }                 
               
                System.out.println("Login successful!");
                Assignment.loginAL = DataIO.checkName2(input);
                
                Assignment.fifth = new AcademicLeaderDashboard();
                
                x.setVisible(false);
                Assignment.fifth.setVisible(true);
                Assignment.fifth.setLocationRelativeTo(null);
                
            } else if(e.getSource() == lecturer){
                String input = JOptionPane.showInputDialog("Enter username:");
                if(DataIO.checkName3(input) == null){
                    throw new Exception();
                }                                               
                String password = JOptionPane.showInputDialog("Enter password:");
                if(!DataIO.checkName3(input).getPassword().equals(password)){
                    throw new Exception();
                }                 
                System.out.println("Login successful!");
                Assignment.loginLecturer = DataIO.checkName3(input);
                
                Assignment.fourth = new Lecturerpage();
                
                x.setVisible(false);
                Assignment.fourth.setVisible(true);
                Assignment.fourth.setLocationRelativeTo(null);
                
            } else if (e.getSource() == student){
                String input = JOptionPane.showInputDialog("Enter username:");
                if(DataIO.checkName4(input) == null){
                    throw new Exception();
                }                                               
                String password = JOptionPane.showInputDialog("Enter password:");
                if(!DataIO.checkName4(input).getPassword().equals(password)){
                    throw new Exception();
                }                 
                System.out.println("Login successful!");
                Assignment.loginStudent = DataIO.checkName4(input);
                
                Assignment.third = new StudentPage();
                
                x.setVisible(false);
                Assignment.third.setVisible(true);
                Assignment.third.setLocationRelativeTo(null);
                
            }
        }catch(Exception ex){
            // already used e, so Exception must ex
            JOptionPane.showMessageDialog(x, "Invalid input!");
        }            
    }
    
    // Public just so other packages can use them
    public JFrame x;
    public JPanel y;    
    public JButton adminStaff, academicLeader, lecturer, student, exit;
    
    public Login(){
        // the Frame
        x = new JFrame("Login System");
        x.setSize(450, 400); // size of the frame
        x.setLocationRelativeTo(null); // set location to null (default) = center of the screen          
        x.setTitle("Login Page");
        
        // BorderLayout is better than FlowLayout, it's organized and has 5 direction, north,east,south,west,center
        x.setLayout(new BorderLayout());         
      
        // add a content pane in the frame, so that buttons are also prioritize in the frame, 
        // -not just labels and titles
        // set the colour to almost white
        x.getContentPane().setBackground(new Color(240, 240, 245)); 
      
        
        // the Frame Panel
        y = new JPanel();
        y.setBackground(new Color(70, 130, 180));
        // set the colour to steel blue
        y.setPreferredSize(new Dimension(450, 100));
        y.setLayout(new GridBagLayout());
        // made sure that the panel can be seen               
        
        // the Label
        JLabel titleLabel = new JLabel("Login System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 32));
        titleLabel.setForeground(Color.white);        
        y.add(titleLabel); // Panel add Label
        
        // the Buttons        
        JPanel buttonPanel = new JPanel();
        
        // set the Panel to GridLayout, which is a Layout that is a consistent layout,
        // - every component must use the same GridLayout
        buttonPanel.setLayout(new GridLayout(2, 2, 20, 20));
        
        // create border for button panel
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(40, 40, 20, 40));
        buttonPanel.setBackground(new Color(240, 240, 245));
        
        // Create styled buttons       
        // blue coloured
        adminStaff = createStyledButton("Admin Staff", new Color(70, 130, 180));
        // green coloured
        academicLeader = createStyledButton("Academic Leader", new Color(34, 139, 34));
        // yellow coloured
        lecturer = createStyledButton("Lecturer", new Color(255, 140, 0));
        // red coloured
        student = createStyledButton("Student", new Color(220, 20, 60));     
        
          // Add buttons to panel
        buttonPanel.add(adminStaff);
        buttonPanel.add(academicLeader);
        buttonPanel.add(lecturer);
        buttonPanel.add(student);               
        
        // Exit Button Panel
        JPanel exitPanel = new JPanel();
        exitPanel.setBackground(new Color(240, 240, 245));
        exitPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 20, 40));
        exit = new JButton("Exit");
        exit.setPreferredSize(new Dimension(370, 40));
        exit.setFont(new Font("Arial", Font.BOLD, 14));
        exit.setBackground(new Color(200, 200, 200));
        exit.setForeground(Color.BLACK);
        exit.setFocusPainted(false);
        exit.setBorder(BorderFactory.createLineBorder(new Color(150, 150, 150), 1));
        exit.addActionListener(this);
        exitPanel.add(exit);
        
        // add functions to the buttons
        adminStaff.addActionListener(this); // this = the object that calls the class 
        academicLeader.addActionListener(this); // in this case ( one = new Login();
        lecturer.addActionListener(this);
        student.addActionListener(this);
        exit.addActionListener(this);
        
        // add the features in the JFrame one by one
        x.add(y, BorderLayout.NORTH); // Frame add Panel        
        x.add(buttonPanel, BorderLayout.CENTER);
        x.add(exitPanel, BorderLayout.SOUTH);
        x.setVisible(true);                
        }        
    
    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        return button;        
    }
}    

