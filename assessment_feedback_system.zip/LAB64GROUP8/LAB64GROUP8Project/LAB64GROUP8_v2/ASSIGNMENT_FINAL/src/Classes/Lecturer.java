
package Classes;

public class Lecturer extends User{
    
    // extra private fields than common fields
    private String assignedTo; 
    private String module;     

    // Inheritance applied
    public Lecturer(String username, String password, String userID, String fullname, String email, String phone, String age, String assignedTo, String module) {
        super(username, password, userID, fullname, email, phone, age);
        this.assignedTo = assignedTo;
        this.module = module;
    }

    // Extra Getters and Setters for Lecturer
    public String getAssignedTo() { return assignedTo; }
    public void setAssignedTo(String assignedTo) { this.assignedTo = assignedTo; }

    public String getModule() { return module; }
    public void setModule(String module) { this.module = module; }

    // Polymorphism applied
    @Override
    public String getRole() {
        return "Lecturer";
    }
}