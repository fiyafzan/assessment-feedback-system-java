package Classes;

// Inheritance applied
public class AdminStaff extends User {   
    
    public AdminStaff(String username, String password, String userID, String fullname, String email, String phone, String age) {
        // Send data up to the User class
        super(username, password, userID, fullname, email, phone, age);
    }

    // Polymorphism applied
    @Override
    public String getRole() {
        return "Admin Staff";
    }   
}
