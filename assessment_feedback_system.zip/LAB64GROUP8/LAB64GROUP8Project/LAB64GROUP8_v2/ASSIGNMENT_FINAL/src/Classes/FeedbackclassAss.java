
package Classes;

public class FeedbackclassAss {
    private String Module;
    private String studentName;
    private String assessmentType;
    private String feedback;

    public FeedbackclassAss(String Module, String studentName, String assessmentType, String feedback) {
        this.Module = Module;
        this.studentName = studentName;
        this.assessmentType = assessmentType;
        this.feedback = feedback;
    }

    public String getModule() {
        return Module;
    }

    public String getStudentName() {
        return studentName;
    }

    public String getAssessmentType() {
        return assessmentType;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setModule(String Module) {
        this.Module = Module;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setAssessmentType(String assessmentType) {
        this.assessmentType = assessmentType;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    
    
    
}
