package Classes;

// Inheritance applied
public class AcademicLeader extends User {
    
    private String lecturers; 

    public AcademicLeader(String username, String password, String userID, 
                          String fullname, String email, String phone, 
                          String age, String lecturers) {
        super(username, password, userID, fullname, email, phone, age);
        this.lecturers = lecturers;
    }
    
    // Getter and Setter for Lecturer (extra feature)
    public String getLecturers() { return lecturers; }
    public void setLecturers(String lecturers) { this.lecturers = lecturers; }
    
    public String getName() { return getFullname(); }       
    public void setName(String name) { setFullname(name); } 
    public String getPhoneNumber() { return getPhone(); }   
    public void setPhoneNumber(String phone) { setPhone(phone); } 

    // Polymorphism applied
    @Override
    public String getRole() {
        return "Academic Leader";
    }
    
    public void displayDashboard() {
        System.out.println("=== Academic Leader Dashboard ===");
        System.out.println("Welcome, " + getFullname());
    }
    
    public String toFileString() {
        return getUserID() + "|" + 
               getFullname() + "|" + 
               getEmail() + "|" + 
               getPassword() + "|" + 
               getPhone();
    }
    
    public static AcademicLeader fromFileString(String line) {
        String[] parts = line.split("\\|");
        if (parts.length >= 5) {
            // parts: userID | fullname | email | password | phone
            return new AcademicLeader(
                parts[1],  // username = fullname
                parts[3],  // password
                parts[0],  // userID
                parts[1],  // fullname
                parts[2],  // email
                parts[4],  // phone
                "",        // age (not stored in our file)
                ""         // lecturers
            );
        }
        return null;
    }
}