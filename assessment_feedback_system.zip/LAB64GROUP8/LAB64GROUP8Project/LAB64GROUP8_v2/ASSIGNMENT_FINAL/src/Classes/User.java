package Classes;

// Abstraction applied
public abstract class User {
    
    // Encapsulation applied
    // Common fields for ALL users
    protected String username;
    protected String password;
    protected String userID;
    protected String fullname;
    protected String email;
    protected String phone;
    protected String age;

    // Constructor for common data
    public User(String username, String password, String userID, String fullname, String email, String phone, String age) {
        this.username = username;
        this.password = password;
        this.userID = userID;
        this.fullname = fullname;
        this.email = email;
        this.phone = phone;
        this.age = age;
    }
    
    // Common Getters
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getUserID() {
        return userID;
    }

    public String getFullname() {
        return fullname;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getAge() {
        return age;
    }

    // Common Setters
    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setAge(String age) {
        this.age = age;
    }
    
    
    // Abstract Method
    public abstract String getRole();
}
