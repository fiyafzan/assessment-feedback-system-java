
package Classes;

public class AssessmentTypeAss {
    private String Module,assessmentType;
    private int weightage,MaxMark;

    public AssessmentTypeAss(String Module, String AssessmentType, int weightage, int MaxMark) {
        this.Module = Module;
        this.assessmentType = AssessmentType;
        this.weightage = weightage;
        this.MaxMark = MaxMark;
    }

    public String getModule() {
        return Module;
    }

    public String getAssessmentType() {
        return assessmentType;
    }

    public int getWeightage() {
        return weightage;
    }

    public int getMaxMark() {
        return MaxMark;
    }

    public void setModule(String Module) {
        this.Module = Module;
    }

    public void setAssessmentType(String AssessmentType) {
        this.assessmentType = AssessmentType;
    }

    public void setWeightage(int weightage) {
        this.weightage = weightage;
    }

    public void setMaxMark(int MaxMark) {
        this.MaxMark = MaxMark;
    }
    

    
    
    

   
    
    
    
}
