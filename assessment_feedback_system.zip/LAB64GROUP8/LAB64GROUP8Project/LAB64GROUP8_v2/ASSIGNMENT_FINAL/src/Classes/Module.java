package Classes;

import java.util.ArrayList;

public class Module {    
    private String moduleName; // e.g., "Object Oriented Java"
    private ArrayList<String> classNames;
    
    // Constructor now only takes Name
    public Module(String moduleName) {
        this.moduleName = moduleName;
        this.classNames = new ArrayList<>();
    }

    //getter
    public String getModuleName() {
        return moduleName;
    }

    public ArrayList<String> getClassNames() {
        return classNames;
    }
    
    //setter
    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }
    
    public void addClass(String newClass){
        classNames.add(newClass);
    }
    
    // Helper for DataIO
    public String getClassesAsString() {
        if (classNames.isEmpty()){
            return "None";
        }
        return String.join(",", classNames);
    }

    @Override
    public String toString() {
        return "Module{" + "moduleName=" + moduleName + '}';
    }        
}
