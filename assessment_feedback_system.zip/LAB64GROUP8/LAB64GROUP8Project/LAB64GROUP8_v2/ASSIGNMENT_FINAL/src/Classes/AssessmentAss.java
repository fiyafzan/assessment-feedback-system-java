
package Classes;

public class AssessmentAss {
    private String Module;
    private String assessmentType;
    private String studentName;
    private int mark;

    public AssessmentAss(String Module, String assessmentType, String studentName, int mark) {
        this.Module = Module;
        this.assessmentType = assessmentType;
        this.studentName = studentName;
        this.mark = mark;
    }

    public String getModule() {
        return Module;
    }

    public String getAssessmentType() {
        return assessmentType;
    }

    public String getStudentName() {
        return studentName;
    }

    public int getMark() {
        return mark;
    }

    public void setModule(String Module) {
        this.Module = Module;
    }

    public void setAssessmentType(String assessmentType) {
        this.assessmentType = assessmentType;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setMark(int mark) {
        this.mark = mark;
    }

    
    
    
}
